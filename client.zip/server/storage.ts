import { notes, folders, users, type Note, type InsertNote, type Folder, type InsertFolder, type User, type InsertUser } from "@shared/schema";
import { db } from "./db";
import { eq, and, isNull } from "drizzle-orm";

export interface IStorage {
  getAllNotes(): Promise<Note[]>;
  getNoteById(id: number): Promise<Note | undefined>;
  createNote(note: InsertNote): Promise<Note>;
  updateNote(id: number, note: Partial<InsertNote>): Promise<Note | undefined>;
  deleteNote(id: number): Promise<boolean>;
  getAllFolders(): Promise<Folder[]>;
  getFolderById(id: number): Promise<Folder | undefined>;
  createFolder(folder: InsertFolder): Promise<Folder>;
  updateFolder(id: number, folder: Partial<InsertFolder>): Promise<Folder | undefined>;
  deleteFolder(id: number): Promise<boolean>;
  // User methods for OAuth preparation
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(insertUser: InsertUser): Promise<User>;
}

export class MemStorage implements IStorage {
  private notes: Map<number, Note>;
  private folders: Map<number, Folder>;
  private currentNoteId: number;
  private currentFolderId: number;

  constructor() {
    this.notes = new Map();
    this.folders = new Map();
    this.currentNoteId = 1;
    this.currentFolderId = 1;
    this.initializeWithSampleData();
  }

  private initializeWithSampleData() {
    // Create sample folders
    const sampleFolders = [
      { name: "Business", parentId: null },
      { name: "Psychology", parentId: null },
      { name: "Philosophy", parentId: null },
      { name: "Books", parentId: 1 },
      { name: "Strategies", parentId: 1 },
      { name: "Mindset", parentId: 2 },
    ];

    sampleFolders.forEach(folderData => {
      const folder: Folder = {
        id: this.currentFolderId++,
        name: folderData.name,
        parentId: folderData.parentId,
        created: new Date()
      };
      this.folders.set(folder.id, folder);
    });

    const sampleNotes = [
      {
        title: "Rich Dad's Cash Flow Quadrant",
        content: "The key difference between an employee and a business owner is that one works for money, while the other builds systems that generate money. Understanding this fundamental shift in mindset is crucial for anyone looking to achieve financial independence.",
        tags: ['business', 'wealth', 'mindset'],
        category: 'business',
        folderId: 4
      },
      {
        title: "Influence: The Psychology of Persuasion",
        content: "The principle of social proof states that people tend to look at others' actions to determine their own behavior, especially in uncertain situations. This powerful psychological trigger can be leveraged in marketing and leadership.",
        tags: ['psychology', 'marketing', 'influence'],
        category: 'psychology',
        folderId: 6
      },
      {
        title: "100M Offers by Alex Hormozi",
        content: "The grand slam offer framework: The better your offer, the less you need to be good at everything else in marketing and sales. Focus on creating irresistible value propositions that customers can't refuse.",
        tags: ['marketing', 'business', 'sales'],
        category: 'business',
        folderId: 4
      },
      {
        title: "Steal Like an Artist",
        content: "Nothing is completely original. All creative work builds on what came before. Embrace influence, don't run away from it. The key is to transform your influences into something uniquely yours.",
        tags: ['creativity', 'art', 'mindset'],
        category: 'art',
        folderId: null
      },
      {
        title: "Man's Search for Meaning",
        content: "Those who have a 'why' to live can bear with almost any 'how'. Success, like happiness, cannot be pursued; it must ensue from meaningful work and relationships.",
        tags: ['psychology', 'philosophy', 'meaning'],
        category: 'philosophy',
        folderId: 3
      },
      {
        title: "Finding My Virginity",
        content: "Business opportunities are like buses, there's always another one coming. The key is to recognize them when they appear and have the courage to act on them.",
        tags: ['business', 'entrepreneurship', 'opportunities'],
        category: 'business',
        folderId: 1
      },
      {
        title: "The Choice Factory",
        content: "Understanding behavioral science is crucial for effective marketing. People make decisions based on cognitive biases and mental shortcuts rather than rational analysis.",
        tags: ['psychology', 'marketing', 'behavior'],
        category: 'psychology',
        folderId: 2
      },
      {
        title: "Dopamine and Decision Making",
        content: "Neuroscience research shows that dopamine not only rewards us for good choices but helps with decision making and risk assessment. Understanding this can improve both personal and business decisions.",
        tags: ['biology', 'psychology', 'neuroscience'],
        category: 'biology',
        folderId: 2
      },
      {
        title: "High Performance Habits",
        content: "The most successful entrepreneurs maintain strict routines and habits that optimize their energy and focus throughout the day. Consistency in small actions leads to extraordinary results.",
        tags: ['productivity', 'habits', 'performance'],
        category: 'psychology',
        folderId: 6
      },
      {
        title: "Strategic Business Thinking",
        content: "Effective strategy isn't about being better at the same things; it's about choosing to do different things or doing things differently. Competitive advantage comes from uniqueness, not just efficiency.",
        tags: ['strategy', 'business', 'competitive-advantage'],
        category: 'business',
        folderId: 5
      }
    ];

    sampleNotes.forEach(noteData => {
      const note: Note = {
        id: this.currentNoteId++,
        ...noteData,
        connections: [],
        created: new Date()
      };
      this.notes.set(note.id, note);
    });

    // Generate random connections between notes
    this.generateConnections();
    
    // Log connection count for debugging
    console.log(`Initialized ${this.notes.size} notes with connections on startup`);
  }

  private generateConnections() {
    const allNotes = Array.from(this.notes.values());
    
    allNotes.forEach(note => {
      const connectionCount = Math.floor(Math.random() * 3) + 1;
      const possibleConnections = allNotes.filter(n => n.id !== note.id);
      const connections: number[] = [];
      
      for (let i = 0; i < connectionCount && i < possibleConnections.length; i++) {
        const randomNote = possibleConnections[Math.floor(Math.random() * possibleConnections.length)];
        if (!connections.includes(randomNote.id)) {
          connections.push(randomNote.id);
        }
      }
      
      note.connections = connections;
      this.notes.set(note.id, note);
    });
  }

  async getAllNotes(): Promise<Note[]> {
    return Array.from(this.notes.values());
  }

  async getNoteById(id: number): Promise<Note | undefined> {
    return this.notes.get(id);
  }

  async createNote(insertNote: InsertNote): Promise<Note> {
    const note: Note = {
      id: this.currentNoteId++,
      title: insertNote.title,
      content: insertNote.content,
      tags: insertNote.tags || [],
      category: insertNote.category,
      folderId: insertNote.folderId || null,
      userId: insertNote.userId || null,
      connections: insertNote.connections || [],
      created: new Date(),
      updated: new Date(),
      type: insertNote.type || 'text',
      imageData: insertNote.imageData || null,
      mimeType: insertNote.mimeType || null
    };
    this.notes.set(note.id, note);
    return note;
  }

  async updateNote(id: number, updateData: Partial<InsertNote>): Promise<Note | undefined> {
    const existingNote = this.notes.get(id);
    if (!existingNote) return undefined;
    
    const updatedNote: Note = {
      ...existingNote,
      ...updateData,
      tags: Array.isArray(updateData.tags) ? updateData.tags : existingNote.tags,
      connections: Array.isArray(updateData.connections) ? updateData.connections : existingNote.connections
    };
    this.notes.set(id, updatedNote);
    return updatedNote;
  }

  async deleteNote(id: number): Promise<boolean> {
    return this.notes.delete(id);
  }

  async getAllFolders(): Promise<Folder[]> {
    return Array.from(this.folders.values());
  }

  async getFolderById(id: number): Promise<Folder | undefined> {
    return this.folders.get(id);
  }

  async createFolder(insertFolder: InsertFolder): Promise<Folder> {
    const folder: Folder = {
      id: this.currentFolderId++,
      name: insertFolder.name,
      parentId: insertFolder.parentId || null,
      created: new Date()
    };
    this.folders.set(folder.id, folder);
    return folder;
  }

  async updateFolder(id: number, updateData: Partial<InsertFolder>): Promise<Folder | undefined> {
    const existingFolder = this.folders.get(id);
    if (!existingFolder) return undefined;
    
    const updatedFolder: Folder = {
      ...existingFolder,
      ...updateData
    };
    this.folders.set(id, updatedFolder);
    return updatedFolder;
  }

  async deleteFolder(id: number): Promise<boolean> {
    return this.folders.delete(id);
  }

  // User methods for OAuth preparation
  async getUser(id: number): Promise<User | undefined> {
    // For now, return undefined as we don't have OAuth yet
    return undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    // For now, return undefined as we don't have OAuth yet
    return undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    // For now, throw an error as we don't have OAuth yet
    throw new Error("User creation not implemented in MemStorage");
  }
}

export class DatabaseStorage implements IStorage {
  async getAllNotes(): Promise<Note[]> {
    return await db.select().from(notes);
  }

  async getNoteById(id: number): Promise<Note | undefined> {
    const [note] = await db.select().from(notes).where(eq(notes.id, id));
    return note || undefined;
  }

  async createNote(insertNote: InsertNote): Promise<Note> {
    const [note] = await db
      .insert(notes)
      .values(insertNote)
      .returning();
    return note;
  }

  async updateNote(id: number, updateData: Partial<InsertNote>): Promise<Note | undefined> {
    const [note] = await db
      .update(notes)
      .set({ ...updateData, updated: new Date() })
      .where(eq(notes.id, id))
      .returning();
    return note || undefined;
  }

  async deleteNote(id: number): Promise<boolean> {
    const result = await db.delete(notes).where(eq(notes.id, id));
    return result.rowCount > 0;
  }

  async getAllFolders(): Promise<Folder[]> {
    return await db.select().from(folders);
  }

  async getFolderById(id: number): Promise<Folder | undefined> {
    const [folder] = await db.select().from(folders).where(eq(folders.id, id));
    return folder || undefined;
  }

  async createFolder(insertFolder: InsertFolder): Promise<Folder> {
    // Check for duplicates with the same name and parent
    const existingFolder = await db
      .select()
      .from(folders)
      .where(and(
        eq(folders.name, insertFolder.name),
        insertFolder.parentId 
          ? eq(folders.parentId, insertFolder.parentId)
          : isNull(folders.parentId)
      ));
    
    if (existingFolder.length > 0) {
      throw new Error(`Folder "${insertFolder.name}" already exists in this location`);
    }
    
    const [folder] = await db
      .insert(folders)
      .values(insertFolder)
      .returning();
    return folder;
  }

  async updateFolder(id: number, updateData: Partial<InsertFolder>): Promise<Folder | undefined> {
    const [folder] = await db
      .update(folders)
      .set(updateData)
      .where(eq(folders.id, id))
      .returning();
    return folder || undefined;
  }

  async deleteFolder(id: number): Promise<boolean> {
    const result = await db.delete(folders).where(eq(folders.id, id));
    return result.rowCount > 0;
  }

  // User methods for OAuth preparation
  async getUser(id: number): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }
}

export const storage = new DatabaseStorage();
