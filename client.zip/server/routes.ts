import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertNoteSchema, insertFolderSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  // Get all notes
  app.get("/api/notes", async (req, res) => {
    try {
      const notes = await storage.getAllNotes();
      res.json(notes);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch notes" });
    }
  });

  // Get note by ID
  app.get("/api/notes/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ error: "Invalid note ID" });
      }
      
      const note = await storage.getNoteById(id);
      if (!note) {
        return res.status(404).json({ error: "Note not found" });
      }
      
      res.json(note);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch note" });
    }
  });

  // Create new note
  app.post("/api/notes", async (req, res) => {
    try {
      const validatedData = insertNoteSchema.parse(req.body);
      const note = await storage.createNote(validatedData);
      res.status(201).json(note);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ error: "Invalid note data", details: error.errors });
      } else {
        res.status(500).json({ error: "Failed to create note" });
      }
    }
  });

  // Update note
  app.put("/api/notes/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ error: "Invalid note ID" });
      }
      
      const validatedData = insertNoteSchema.partial().parse(req.body);
      const note = await storage.updateNote(id, validatedData);
      
      if (!note) {
        return res.status(404).json({ error: "Note not found" });
      }
      
      res.json(note);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ error: "Invalid note data", details: error.errors });
      } else {
        res.status(500).json({ error: "Failed to update note" });
      }
    }
  });

  // PATCH endpoint for note updates
  app.patch("/api/notes/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ error: "Invalid note ID" });
      }
      
      const validatedData = insertNoteSchema.partial().parse(req.body);
      const note = await storage.updateNote(id, validatedData);
      
      if (!note) {
        return res.status(404).json({ error: "Note not found" });
      }
      
      res.json(note);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ error: "Invalid note data", details: error.errors });
      } else {
        console.error('PATCH /api/notes/:id error:', error);
        res.status(500).json({ error: "Failed to update note" });
      }
    }
  });

  // Delete note
  app.delete("/api/notes/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ error: "Invalid note ID" });
      }
      
      const success = await storage.deleteNote(id);
      if (!success) {
        return res.status(404).json({ error: "Note not found" });
      }
      
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: "Failed to delete note" });
    }
  });

  // Folder routes
  app.get("/api/folders", async (req, res) => {
    try {
      const folders = await storage.getAllFolders();
      res.json(folders);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch folders" });
    }
  });

  app.get("/api/folders/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ error: "Invalid folder ID" });
      }
      
      const folder = await storage.getFolderById(id);
      if (!folder) {
        return res.status(404).json({ error: "Folder not found" });
      }
      
      res.json(folder);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch folder" });
    }
  });

  app.post("/api/folders", async (req, res) => {
    try {
      const validatedData = insertFolderSchema.parse(req.body);
      const folder = await storage.createFolder(validatedData);
      res.status(201).json(folder);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ error: "Invalid folder data", details: error.errors });
      } else {
        res.status(500).json({ error: "Failed to create folder" });
      }
    }
  });

  app.put("/api/folders/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ error: "Invalid folder ID" });
      }
      
      const validatedData = insertFolderSchema.partial().parse(req.body);
      const folder = await storage.updateFolder(id, validatedData);
      
      if (!folder) {
        return res.status(404).json({ error: "Folder not found" });
      }
      
      res.json(folder);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ error: "Invalid folder data", details: error.errors });
      } else {
        res.status(500).json({ error: "Failed to update folder" });
      }
    }
  });

  // PATCH endpoint for folder updates
  app.patch("/api/folders/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ error: "Invalid folder ID" });
      }
      
      const validatedData = insertFolderSchema.partial().parse(req.body);
      const folder = await storage.updateFolder(id, validatedData);
      
      if (!folder) {
        return res.status(404).json({ error: "Folder not found" });
      }
      
      res.json(folder);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ error: "Invalid folder data", details: error.errors });
      } else {
        console.error('PATCH /api/folders/:id error:', error);
        res.status(500).json({ error: "Failed to update folder" });
      }
    }
  });

  app.delete("/api/folders/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      if (isNaN(id)) {
        return res.status(400).json({ error: "Invalid folder ID" });
      }
      
      const success = await storage.deleteFolder(id);
      if (!success) {
        return res.status(404).json({ error: "Folder not found" });
      }
      
      res.status(204).send();
    } catch (error) {
      res.status(500).json({ error: "Failed to delete folder" });
    }
  });

  // Generate new graph data
  app.post("/api/graph/regenerate", async (req, res) => {
    try {
      // For database storage, simply return all notes (no regeneration needed)
      const notes = await storage.getAllNotes();
      res.json(notes);
    } catch (error) {
      console.error('Graph regeneration error:', error);
      res.status(500).json({ error: "Failed to regenerate graph" });
    }
  });

  // Initialize sample data in database
  app.post("/api/init", async (req, res) => {
    try {
      // Create sample folders first
      const sampleFolders = [
        { name: "Business", parentId: null, userId: null },
        { name: "Psychology", parentId: null, userId: null },
        { name: "Philosophy", parentId: null, userId: null },
      ];

      const createdFolders = [];
      for (const folderData of sampleFolders) {
        const folder = await storage.createFolder(folderData);
        createdFolders.push(folder);
      }

      // Create nested folders
      const businessFolder = createdFolders[0];
      const psychologyFolder = createdFolders[1];
      
      const nestedFolders = [
        { name: "Books", parentId: businessFolder.id, userId: null },
        { name: "Strategies", parentId: businessFolder.id, userId: null },
        { name: "Mindset", parentId: psychologyFolder.id, userId: null },
      ];

      const createdNestedFolders = [];
      for (const folderData of nestedFolders) {
        const folder = await storage.createFolder(folderData);
        createdNestedFolders.push(folder);
      }

      // Create sample notes
      const sampleNotes = [
        {
          title: "Rich Dad's Cash Flow Quadrant",
          content: "# Rich Dad's Cash Flow Quadrant\n\nThe key difference between an **employee** and a **business owner** is that one works for money, while the other builds systems that generate money.\n\n## Key Concepts\n- Employee mindset vs Business owner mindset\n- Building systems that work for you\n- Financial independence through passive income\n\nUnderstanding this fundamental shift in mindset is crucial for anyone looking to achieve financial independence.",
          tags: ['business', 'wealth', 'mindset'],
          category: 'business',
          folderId: createdNestedFolders[0].id, // Books folder
          userId: null,
          connections: []
        },
        {
          title: "Influence: The Psychology of Persuasion",
          content: "# Influence: The Psychology of Persuasion\n\nThe principle of **social proof** states that people tend to look at others' actions to determine their own behavior, especially in uncertain situations.\n\n## Key Principles\n1. Social Proof\n2. Commitment and Consistency\n3. Reciprocity\n4. Authority\n5. Liking\n6. Scarcity\n\nThis powerful psychological trigger can be leveraged in marketing and leadership.",
          tags: ['psychology', 'marketing', 'influence'],
          category: 'psychology',
          folderId: createdNestedFolders[2].id, // Mindset folder
          userId: null,
          connections: []
        },
        {
          title: "100M Offers by Alex Hormozi",
          content: "# 100M Offers\n\n> The better your offer, the less you need to be good at everything else in marketing and sales.\n\n## Grand Slam Offer Framework\n\n- **Value**: What you're providing\n- **Urgency**: Why they need it now\n- **Scarcity**: Limited availability\n- **Guarantee**: Risk reversal\n\nFocus on creating irresistible value propositions that customers can't refuse.",
          tags: ['marketing', 'business', 'sales'],
          category: 'business',
          folderId: createdNestedFolders[0].id, // Books folder
          userId: null,
          connections: []
        }
      ];

      const createdNotes = [];
      for (const noteData of sampleNotes) {
        const note = await storage.createNote(noteData);
        createdNotes.push(note);
      }

      res.json({ 
        message: "Sample data initialized successfully", 
        folders: [...createdFolders, ...createdNestedFolders],
        notes: createdNotes
      });
    } catch (error) {
      console.error("Error initializing sample data:", error);
      res.status(500).json({ error: "Failed to initialize sample data" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
