import { useEffect, useRef, useMemo, memo } from 'react';
import ForceGraph3D from '3d-force-graph';
import * as THREE from 'three';
import type { Note } from '@shared/schema';

interface Graph3DProps {
  notes: Note[];
  onNodeClick: (note: Note) => void;
  onHomeCameraRef?: (homeCamera: () => void) => void;
  nodeSize?: number;
  particleSize?: number;
  labelThreshold?: number;
  nodeDistance?: number;
}

interface GraphNode {
  id: number;
  name: string;
  val: number;
  color: string;
  note: Note;
}

interface GraphLink {
  source: number;
  target: number;
  color: string;
}

function Graph3DComponent({ notes, onNodeClick, onHomeCameraRef, nodeSize = 1, particleSize = 1, labelThreshold = 400, nodeDistance = 200 }: Graph3DProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const graphRef = useRef<any>(null);
  const homeCameraRef = useRef<(() => void) | null>(null);
  const labelMaterialsRef = useRef<THREE.SpriteMaterial[]>([]);
  const cameraPositionRef = useRef<{ position: THREE.Vector3; lookAt: THREE.Vector3 } | null>(null);

  const getNodeColor = (category: string): string => {
    const colors: Record<string, string> = {
      philosophy: '#FF6B6B',
      science: '#4ECDC4',
      history: '#45B7D1',
      art: '#96CEB4',
      literature: '#FFEEAD',
      psychology: '#D4A5A5',
      technology: '#9B59B6',
      mathematics: '#3498DB',
      biology: '#2ECC71',
      physics: '#E74C3C',
      business: '#FF6B6B'
    };
    return colors[category] || '#ffffff';
  };

  useEffect(() => {
    if (!containerRef.current || !notes.length) return;

    // Save current camera position before recreating graph
    if (graphRef.current && graphRef.current.camera) {
      const camera = graphRef.current.camera();
      const controls = graphRef.current.controls();
      if (camera && controls) {
        cameraPositionRef.current = {
          position: camera.position.clone(),
          lookAt: controls.target.clone()
        };
      }
    }

    // Clear previous label materials
    labelMaterialsRef.current = [];

    const nodes: GraphNode[] = notes.map(note => ({
      id: note.id,
      name: note.title,
      val: (note.connections?.length || 0) + 3,
      color: getNodeColor(note.category),
      note
    }));

    // Extract wiki links from note content and create connections
    const extractWikiLinks = (content: string): string[] => {
      const wikiLinkRegex = /\[\[([^\]]+)\]\]/g;
      const links: string[] = [];
      let match;
      
      while ((match = wikiLinkRegex.exec(content)) !== null) {
        const linkContent = match[1];
        const [title] = linkContent.includes('|') 
          ? linkContent.split('|', 2).map(s => s.trim())
          : [linkContent.trim()];
        links.push(title);
      }
      return links;
    };

    // Create a map of note titles to IDs for quick lookup
    const titleToIdMap = new Map<string, number>();
    notes.forEach(note => {
      titleToIdMap.set(note.title, note.id);
    });

    // Generate links based on wiki links in content
    const links: GraphLink[] = notes.flatMap(note => {
      const wikiLinks = extractWikiLinks(note.content);
      return wikiLinks
        .map(linkedTitle => titleToIdMap.get(linkedTitle))
        .filter(targetId => targetId !== undefined && targetId !== note.id)
        .map(targetId => ({
          source: note.id,
          target: targetId!,
          color: '#ffffff60'
        }));
    });

    const graphData = { nodes, links };

    const graph = ForceGraph3D()(containerRef.current!)
      .graphData(graphData)
      .nodeLabel('name')
      .nodeColor('color')
      .nodeRelSize(6)
      .linkWidth(1)
      .linkColor('color')
      .backgroundColor('#00000000')
      .showNavInfo(false)
      .linkDirectionalParticles(4)
      .linkDirectionalParticleWidth(2 * particleSize)
      .linkDirectionalParticleSpeed(0.004)
      .linkDirectionalParticleColor(() => '#ffffff')
      .linkDirectionalArrowLength(3.5)
      .linkDirectionalArrowRelPos(1)
      .linkDirectionalParticleResolution(8)
      .enableNodeDrag(true)
      .enablePointerInteraction(true)
      .width(containerRef.current!.clientWidth)
      .height(containerRef.current!.clientHeight)

      .onNodeClick((node: GraphNode) => {
        onNodeClick(node.note);
        
        // Animate camera to node
        const distance = 40;
        const distRatio = 1 + distance / Math.hypot(node.x || 0, node.y || 0, node.z || 0);
        
        graph.cameraPosition(
          {
            x: (node.x || 0) * distRatio,
            y: (node.y || 0) * distRatio,
            z: (node.z || 0) * distRatio
          },
          node,
          3000
        );
      })
      .onNodeHover((node: GraphNode | null) => {
        if (containerRef.current) {
          containerRef.current.style.cursor = node ? 'grab' : 'default';
        }
      })
      .nodeThreeObject((node: GraphNode) => {
        const group = new THREE.Group();
        
        // Scale based on nodeSize prop
        const baseSize = 4;
        const scaledSize = baseSize * nodeSize;
        const glowSize = scaledSize * 1.5;
        const outerGlowSize = scaledSize * 2;

        // Main sphere
        const sphere = new THREE.Mesh(
          new THREE.SphereGeometry(scaledSize),
          new THREE.MeshPhongMaterial({
            color: node.color,
            transparent: true,
            opacity: 0.8
          })
        );
        group.add(sphere);

        // Glow effect
        const glowGeometry = new THREE.SphereGeometry(glowSize);
        const glowMaterial = new THREE.MeshBasicMaterial({
          color: node.color,
          transparent: true,
          opacity: 0.3,
          side: THREE.BackSide
        });
        const glow = new THREE.Mesh(glowGeometry, glowMaterial);
        group.add(glow);

        // Outer glow for extra effect
        const outerGlowGeometry = new THREE.SphereGeometry(outerGlowSize);
        const outerGlowMaterial = new THREE.MeshBasicMaterial({
          color: node.color,
          transparent: true,
          opacity: 0.1,
          side: THREE.BackSide
        });
        const outerGlow = new THREE.Mesh(outerGlowGeometry, outerGlowMaterial);
        group.add(outerGlow);

        // Add text label with high resolution
        const canvas = document.createElement('canvas');
        const context = canvas.getContext('2d');
        const fontSize = 32; // Use higher resolution font
        const padding = 12;
        const pixelRatio = window.devicePixelRatio || 1;
        
        if (context) {
          // Measure text at high resolution
          context.font = `${fontSize}px Arial`;
          const textWidth = context.measureText(node.name).width;
          
          // Set canvas size with device pixel ratio for crisp text
          const canvasWidth = (textWidth + padding * 2) * pixelRatio;
          const canvasHeight = (fontSize + padding * 2) * pixelRatio;
          
          canvas.width = canvasWidth;
          canvas.height = canvasHeight;
          
          // Scale context for high DPI
          context.scale(pixelRatio, pixelRatio);
          
          // Re-set font after canvas resize
          context.font = `${fontSize}px Arial`;
          
          // Add background for better visibility
          context.fillStyle = 'rgba(0, 0, 0, 0.7)';
          context.fillRect(0, 0, (textWidth + padding * 2), (fontSize + padding * 2));
          
          // Add text
          context.fillStyle = '#ffffff';
          context.textAlign = 'center';
          context.textBaseline = 'middle';
          
          context.fillText(node.name, (textWidth + padding * 2) / 2, (fontSize + padding * 2) / 2);
        }
        
        const texture = new THREE.CanvasTexture(canvas);
        // Enable better filtering for crisp text
        texture.generateMipmaps = false;
        texture.minFilter = THREE.LinearFilter;
        texture.magFilter = THREE.LinearFilter;
        
        const labelMaterial = new THREE.SpriteMaterial({
          map: texture,
          transparent: true,
          opacity: 1.0 // Will be controlled by fade animation
        });
        
        const label = new THREE.Sprite(labelMaterial);
        // Scale down to desired size (16px equivalent)
        const scaleFactor = 16 / fontSize; // Scale down from 32 to 16
        label.scale.set(
          (canvas.width / pixelRatio) * scaleFactor / 8, 
          (canvas.height / pixelRatio) * scaleFactor / 8, 
          1
        );
        label.position.set(0, scaledSize + 6, 0); // Position closer to node center
        
        // Store reference for fade updates
        labelMaterialsRef.current.push(labelMaterial);
        
        group.add(label);

        return group;
      });

    graphRef.current = graph;

    // Configure force simulation for node distance
    graph.d3Force('link')?.distance(nodeDistance);
    graph.d3Force('charge')?.strength(-nodeDistance * 2);

    // Force immediate centering and ensure labels are visible
    const centerGraphAndShowLabels = () => {
      if (graph) {
        // Force graph to center at origin
        graph.cameraPosition(
          { x: 0, y: 0, z: 350 },  // Camera position - centered at origin
          { x: 0, y: 0, z: 0 },    // Look at origin
          0                        // No animation on initial load
        );
        
        // Set controls to center
        const controls = graph.controls();
        if (controls) {
          controls.target.set(0, 0, 0);
          controls.update();
        }
        
        // Force refresh labels by updating the graph
        graph.refresh();
      }
    };
    
    // Center immediately and multiple times to ensure it sticks
    centerGraphAndShowLabels();
    setTimeout(centerGraphAndShowLabels, 100);
    setTimeout(centerGraphAndShowLabels, 500);
    setTimeout(centerGraphAndShowLabels, 1500);

    // Update label opacity based on camera distance from origin
    const updateLabelOpacity = () => {
      if (!graph) return;
      
      const camera = graph.camera();
      // Calculate distance from camera to origin (0,0,0)
      const cameraDistance = Math.sqrt(
        camera.position.x * camera.position.x +
        camera.position.y * camera.position.y +
        camera.position.z * camera.position.z
      );
      
      // Calculate opacity based on zoom distance with smooth fade
      const fadeStartDistance = 800; // X point - start fading at this distance
      const fadeEndDistance = 1500;  // Y point - completely fade at this distance
      const maxOpacity = 1.0; // 100% opacity when close
      
      let opacity;
      if (cameraDistance <= fadeStartDistance) {
        // 100% opacity when camera is closer than fade start
        opacity = maxOpacity;
      } else if (cameraDistance >= fadeEndDistance) {
        // Minimum opacity when camera is beyond fade end (never completely fade out)
        opacity = 0.3;
      } else {
        // Smooth fade between start and end points
        const fadeProgress = (cameraDistance - fadeStartDistance) / (fadeEndDistance - fadeStartDistance);
        opacity = Math.max(0.3, maxOpacity * (1 - fadeProgress));
      }
      
      // Update all stored label materials
      labelMaterialsRef.current.forEach((material) => {
        if (material) {
          material.opacity = opacity;
        }
      });
    };

    // Enable fade animation based on zoom distance
    const animate = () => {
      updateLabelOpacity();
      requestAnimationFrame(animate);
    };
    animate();

    // Home camera function
    const homeCamera = () => {
      console.log('homeCamera called, graphRef.current:', graphRef.current);
      // Wait for graph to be ready if it's not initialized yet
      const attemptHomeCamera = () => {
        if (graphRef.current) {
          const graph = graphRef.current;
          
          // Reset camera to center at origin
          graph.cameraPosition(
            { x: 0, y: 0, z: 400 }, // Camera position
            { x: 0, y: 0, z: 0 },   // Look at center
            2000                    // Animation duration
          );
          
          // Also reset controls target
          setTimeout(() => {
            const controls = graph.controls();
            if (controls) {
              controls.target.set(0, 0, 0);
              controls.update();
            }
          }, 100);
        } else {
          // Retry after a short delay if graph is not ready
          setTimeout(attemptHomeCamera, 100);
        }
      };
      
      attemptHomeCamera();
    };

    // Store the function reference
    homeCameraRef.current = homeCamera;
    
    // Expose function immediately (before timeout)
    if (onHomeCameraRef) {
      console.log('Calling onHomeCameraRef with homeCamera function');
      onHomeCameraRef(homeCamera);
    }

    // Enable middle mouse button panning and expose home camera function
    setTimeout(() => {
      const controls = graph.controls();
      if (controls) {
        // Enable all mouse interactions
        controls.enablePan = true;
        controls.enableZoom = true;
        controls.enableRotate = true;
        
        // Set mouse buttons for different actions
        // LEFT: Node dragging (handled by force-graph)
        // RIGHT: View rotation
        // MIDDLE: Pan
        controls.mouseButtons = {
          LEFT: null, // Disable left mouse rotation to allow node dragging
          MIDDLE: THREE.MOUSE.PAN,
          RIGHT: THREE.MOUSE.ROTATE
        };
        
        // Set touch gestures
        controls.touches = {
          ONE: THREE.TOUCH.ROTATE,
          TWO: THREE.TOUCH.DOLLY_PAN
        };
        
        // Additional panning settings
        controls.panSpeed = 0.1; // Reduced from 0.5 to make panning less sensitive
        controls.keyPanSpeed = 0.5;
        controls.enableKeys = true;
        
        // Allow continuous panning
        controls.enableDamping = true;
        controls.dampingFactor = 0.05;
        
        // Set zoom limits
        controls.minDistance = 10;
        controls.maxDistance = 2000;
        
        // Enable keyboard controls (arrow keys for panning)
        controls.keys = {
          LEFT: 37,  // Arrow left
          UP: 38,    // Arrow up
          RIGHT: 39, // Arrow right
          BOTTOM: 40 // Arrow down
        };
      }
      
      // Graph is now fully initialized
      // Restore camera position if we have one saved
      if (cameraPositionRef.current) {
        const camera = graph.camera();
        const controls = graph.controls();
        if (camera && controls) {
          camera.position.copy(cameraPositionRef.current.position);
          controls.target.copy(cameraPositionRef.current.lookAt);
          controls.update();
        }
      }
    }, 100);

    // Handle window resize
    const handleResize = () => {
      if (containerRef.current) {
        graph.width(containerRef.current.clientWidth);
        graph.height(containerRef.current.clientHeight);
      }
    };

    window.addEventListener('resize', handleResize);

    return () => {
      window.removeEventListener('resize', handleResize);
      if (graphRef.current) {
        graphRef.current = null;
      }
    };
  }, [notes, onNodeClick, onHomeCameraRef]); // Dependencies for graph recreation - removed nodeDistance

  // Separate effect for updating node distance without recreating the graph
  useEffect(() => {
    if (!graphRef.current) return;
    
    // Add a longer delay to ensure the graph is fully initialized
    const timeoutId = setTimeout(() => {
      if (!graphRef.current) return;
      
      const graph = graphRef.current;
      
      try {
        // Update only the link distance force
        const linkForce = graph.d3Force('link');
        
        if (linkForce && typeof linkForce.distance === 'function') {
          // Update the distance for links
          linkForce.distance(nodeDistance);
          
          // Also adjust the charge force to compensate
          // This prevents unlinked nodes from drifting when link distance changes
          const chargeForce = graph.d3Force('charge');
          if (chargeForce && typeof chargeForce.strength === 'function') {
            // Scale charge strength inversely with link distance
            // When links are closer, reduce repulsion to prevent drift
            const chargeStrength = -30 * (nodeDistance / 15); // Normalized to default of 15
            chargeForce.strength(chargeStrength);
            console.log(`Updated forces - Link distance: ${nodeDistance}, Charge strength: ${chargeStrength}`);
          }
          
          // Apply changes without full reheat to minimize disruption
          if (typeof graph.d3AlphaTarget === 'function') {
            // Gently update the simulation
            graph.d3AlphaTarget(0.1).restart();
            
            // Let it settle back down
            setTimeout(() => {
              if (graphRef.current) {
                graphRef.current.d3AlphaTarget(0);
              }
            }, 300);
          } else if (typeof graph.d3ReheatSimulation === 'function') {
            graph.d3ReheatSimulation();
          }
        } else {
          console.log('Link force not available yet');
        }
      } catch (error) {
        console.error('Error updating link distance:', error);
      }
    }, 500); // Increased delay to ensure graph is ready
    
    return () => clearTimeout(timeoutId);
  }, [nodeDistance]);

  // Separate effect for updating node and particle sizes without recreating the graph
  useEffect(() => {
    if (!graphRef.current) return;

    const graph = graphRef.current;
    
    // Update node sizes with original glow effect
    graph.nodeThreeObject((node: GraphNode) => {
      const scaledSize = node.val * nodeSize;
      const group = new THREE.Group();
      
      // Main sphere
      const geometry = new THREE.SphereGeometry(scaledSize, 32, 32);
      const material = new THREE.MeshPhongMaterial({
        color: node.color,
        emissive: node.color,
        emissiveIntensity: 0.2,
        shininess: 100,
        transparent: true,
        opacity: 0.8
      });
      const sphere = new THREE.Mesh(geometry, material);
      group.add(sphere);

      // Glow effect
      const glowSize = scaledSize * 1.5;
      const glowGeometry = new THREE.SphereGeometry(glowSize);
      const glowMaterial = new THREE.MeshBasicMaterial({
        color: node.color,
        transparent: true,
        opacity: 0.3,
        side: THREE.BackSide
      });
      const glow = new THREE.Mesh(glowGeometry, glowMaterial);
      group.add(glow);

      // Outer glow for extra effect
      const outerGlowSize = scaledSize * 2;
      const outerGlowGeometry = new THREE.SphereGeometry(outerGlowSize);
      const outerGlowMaterial = new THREE.MeshBasicMaterial({
        color: node.color,
        transparent: true,
        opacity: 0.1,
        side: THREE.BackSide
      });
      const outerGlow = new THREE.Mesh(outerGlowGeometry, outerGlowMaterial);
      group.add(outerGlow);

      return group;
    });

    // Update particle size
    graph.linkDirectionalParticleWidth(particleSize);
  }, [nodeSize, particleSize]);



  return <div ref={containerRef} className="graph-container" style={{ width: '100%', height: '100%' }} />;
}

// Helper function to extract wiki links from content
const extractWikiLinksFromContent = (content: string): string[] => {
  const wikiLinkRegex = /\[\[([^\]]+)\]\]/g;
  const links: string[] = [];
  let match;
  
  while ((match = wikiLinkRegex.exec(content)) !== null) {
    const linkContent = match[1];
    const [title] = linkContent.includes('|') 
      ? linkContent.split('|', 2).map(s => s.trim())
      : [linkContent.trim()];
    links.push(title);
  }
  return links.sort(); // Sort for consistent comparison
};

// Helper function to check if notes have structurally changed
const areNotesEqual = (prevNotes: Note[], nextNotes: Note[]) => {
  if (prevNotes.length !== nextNotes.length) return false;
  
  // Check if any note's connections or titles have changed (which would affect the graph)
  for (let i = 0; i < prevNotes.length; i++) {
    const prevNote = prevNotes[i];
    const nextNote = nextNotes.find(n => n.id === prevNote.id);
    
    if (!nextNote) return false;
    if (prevNote.title !== nextNote.title) return false;
    if (prevNote.category !== nextNote.category) return false;
    
    // Check connections
    const prevConnections = prevNote.connections || [];
    const nextConnections = nextNote.connections || [];
    if (prevConnections.length !== nextConnections.length) return false;
    
    // Check wiki links (which create visual connections in the graph)
    const prevWikiLinks = extractWikiLinksFromContent(prevNote.content);
    const nextWikiLinks = extractWikiLinksFromContent(nextNote.content);
    if (prevWikiLinks.length !== nextWikiLinks.length) return false;
    for (let j = 0; j < prevWikiLinks.length; j++) {
      if (prevWikiLinks[j] !== nextWikiLinks[j]) return false;
    }
  }
  
  return true;
};

// Memoize the component to prevent unnecessary re-renders
export const Graph3D = memo(Graph3DComponent, (prevProps, nextProps) => {
  // Only re-render if notes structure or handlers actually change
  return (
    areNotesEqual(prevProps.notes, nextProps.notes) &&
    prevProps.onNodeClick === nextProps.onNodeClick &&
    prevProps.onHomeCameraRef === nextProps.onHomeCameraRef &&
    prevProps.nodeSize === nextProps.nodeSize &&
    prevProps.particleSize === nextProps.particleSize &&
    prevProps.labelThreshold === nextProps.labelThreshold &&
    prevProps.nodeDistance === nextProps.nodeDistance
  );
});
