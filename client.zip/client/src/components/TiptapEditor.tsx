import { useEffect, useRef } from "react";
import { useEditor, EditorContent } from "@tiptap/react";
import StarterKit from "@tiptap/starter-kit";
import Typography from "@tiptap/extension-typography";
import Placeholder from "@tiptap/extension-placeholder";
import { Button } from "@/components/ui/button";
import { 
  Bold, 
  Italic, 
  Strikethrough, 
  Code,
  List,
  ListOrdered,
  Quote,
  Heading1,
  Heading2,
  Heading3,
  Undo,
  Redo,
  Minus
} from "lucide-react";
import type { Note } from "@shared/schema";

interface TiptapEditorProps {
  content: string;
  onSave: (content: string) => void;
  isReadOnly?: boolean;
  imageNotes?: Map<string, Note>;
  findNoteByTitle?: (title: string) => Note | undefined;
  onWikiLinkClick?: (title: string) => void;
}

export function TiptapEditor({ 
  content, 
  onSave, 
  isReadOnly = false,
  imageNotes = new Map(),
  findNoteByTitle,
  onWikiLinkClick 
}: TiptapEditorProps) {
  const saveTimeout = useRef<NodeJS.Timeout>();

  const editor = useEditor({
    extensions: [
      StarterKit.configure({
        dropcursor: false,
        gapcursor: false,
        history: {
          depth: 100,
        },
        bold: {
          HTMLAttributes: {
            class: 'font-bold text-white',
          },
        },
        italic: {
          HTMLAttributes: {
            class: 'italic text-gray-300',
          },
        },
        strike: {
          HTMLAttributes: {
            class: 'line-through text-gray-300',
          },
        },
        code: {
          HTMLAttributes: {
            class: 'bg-gray-700 text-blue-400 px-2 py-1 rounded font-mono text-sm',
          },
        },
        codeBlock: {
          HTMLAttributes: {
            class: 'bg-gray-800 text-gray-300 p-4 rounded-lg font-mono text-sm overflow-x-auto my-4',
          },
        },
        bulletList: {
          HTMLAttributes: {
            class: 'list-disc list-inside space-y-2 text-gray-300',
          },
        },
        orderedList: {
          HTMLAttributes: {
            class: 'list-decimal list-inside space-y-2 text-gray-300',
          },
        },
        listItem: {
          HTMLAttributes: {
            class: 'ml-4 text-gray-300',
          },
        },
        blockquote: {
          HTMLAttributes: {
            class: 'border-l-4 border-blue-500 pl-4 italic text-gray-400 my-4',
          },
        },
        heading: {
          levels: [1, 2, 3],
          HTMLAttributes: {
            class: 'font-bold text-white',
          },
        },
        horizontalRule: {
          HTMLAttributes: {
            class: 'border-t border-gray-600 my-4',
          },
        },
        paragraph: {
          HTMLAttributes: {
            class: 'text-gray-300 mb-4 leading-relaxed',
          },
        },
      }),
      Typography.configure({
        openDoubleQuote: false,
        closeDoubleQuote: false,
        openSingleQuote: false,
        closeSingleQuote: false,
        emDash: false,
        ellipsis: false,
      }),
      Placeholder.configure({
        placeholder: "Start typing...",
      }),
    ],
    content: content || "",
    editable: !isReadOnly,
    editorProps: {
      attributes: {
        class: 'prose prose-invert max-w-none focus:outline-none min-h-[400px] p-4',
      },
    },
    parseOptions: {
      preserveWhitespace: 'full',
    },
    onUpdate: ({ editor }) => {
      // Convert HTML back to markdown format for storage
      const markdownContent = convertHtmlToMarkdown(editor.getHTML());
      
      if (onSave) {
        clearTimeout(saveTimeout.current);
        saveTimeout.current = setTimeout(() => {
          onSave(markdownContent);
        }, 500);
      }
    },
  });

  // Convert HTML to markdown for storage
  const convertHtmlToMarkdown = (html: string) => {
    return html
      .replace(/<h1[^>]*>(.*?)<\/h1>/g, '# $1')
      .replace(/<h2[^>]*>(.*?)<\/h2>/g, '## $1')
      .replace(/<h3[^>]*>(.*?)<\/h3>/g, '### $1')
      .replace(/<strong[^>]*>(.*?)<\/strong>/g, '**$1**')
      .replace(/<em[^>]*>(.*?)<\/em>/g, '*$1*')
      .replace(/<code[^>]*>(.*?)<\/code>/g, '`$1`')
      .replace(/<pre[^>]*><code[^>]*>(.*?)<\/code><\/pre>/gs, '```\n$1\n```')
      .replace(/<blockquote[^>]*>(.*?)<\/blockquote>/gs, '> $1')
      .replace(/<ul[^>]*>(.*?)<\/ul>/gs, (match, content) => {
        return content.replace(/<li[^>]*>(.*?)<\/li>/g, '- $1');
      })
      .replace(/<ol[^>]*>(.*?)<\/ol>/gs, (match, content) => {
        let counter = 1;
        return content.replace(/<li[^>]*>(.*?)<\/li>/g, () => `${counter++}. $1`);
      })
      .replace(/<p[^>]*>(.*?)<\/p>/g, '$1\n\n')
      .replace(/<br\s*\/?>/g, '\n')
      .replace(/<hr\s*\/?>/g, '---')
      .replace(/<[^>]*>/g, '') // Remove any remaining HTML tags
      .replace(/\n\s*\n\s*\n/g, '\n\n') // Clean up excessive newlines
      .trim();
  };

  // Convert markdown to HTML for display
  const convertMarkdownToHtml = (markdown: string) => {
    return markdown
      .replace(/^# (.*$)/gm, '<h1>$1</h1>')
      .replace(/^## (.*$)/gm, '<h2>$1</h2>')
      .replace(/^### (.*$)/gm, '<h3>$1</h3>')
      .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
      .replace(/\*(.*?)\*/g, '<em>$1</em>')
      .replace(/`(.*?)`/g, '<code>$1</code>')
      .replace(/```([\s\S]*?)```/g, '<pre><code>$1</code></pre>')
      .replace(/^> (.*$)/gm, '<blockquote>$1</blockquote>')
      .replace(/^- (.*$)/gm, '<ul><li>$1</li></ul>')
      .replace(/^\d+\. (.*$)/gm, '<ol><li>$1</li></ol>')
      .replace(/^---$/gm, '<hr>')
      .replace(/\n\n/g, '</p><p>')
      .replace(/^/, '<p>')
      .replace(/$/, '</p>')
      .replace(/<p><\/p>/g, '')
      .replace(/<\/ul>\s*<ul>/g, '')
      .replace(/<\/ol>\s*<ol>/g, '');
  };

  useEffect(() => {
    if (editor) {
      const htmlContent = convertMarkdownToHtml(content || "");
      editor.commands.setContent(htmlContent);
    }
  }, [content, editor]);

  if (!editor) {
    return null;
  }

  return (
    <div className="tiptap-editor h-full flex flex-col">
      {/* Toolbar */}
      {!isReadOnly && (
        <div className="sticky top-0 z-20 border-b border-gray-700/50 p-2 bg-gray-900/90 backdrop-blur-sm">
          <div className="flex flex-wrap gap-1">
            {/* Text formatting */}
            <Button
              size="sm"
              variant={editor.isActive('bold') ? 'secondary' : 'ghost'}
              onClick={() => editor.chain().focus().toggleBold().run()}
              disabled={!editor.can().chain().focus().toggleBold().run()}
              className="h-8 w-8 p-0 text-blue-400 hover:text-blue-300 hover:bg-blue-400/10"
            >
              <Bold className="h-4 w-4" />
            </Button>
            <Button
              size="sm"
              variant={editor.isActive('italic') ? 'secondary' : 'ghost'}
              onClick={() => editor.chain().focus().toggleItalic().run()}
              disabled={!editor.can().chain().focus().toggleItalic().run()}
              className="h-8 w-8 p-0 text-blue-400 hover:text-blue-300 hover:bg-blue-400/10"
            >
              <Italic className="h-4 w-4" />
            </Button>
            <Button
              size="sm"
              variant={editor.isActive('strike') ? 'secondary' : 'ghost'}
              onClick={() => editor.chain().focus().toggleStrike().run()}
              disabled={!editor.can().chain().focus().toggleStrike().run()}
              className="h-8 w-8 p-0 text-blue-400 hover:text-blue-300 hover:bg-blue-400/10"
            >
              <Strikethrough className="h-4 w-4" />
            </Button>
            <Button
              size="sm"
              variant={editor.isActive('code') ? 'secondary' : 'ghost'}
              onClick={() => editor.chain().focus().toggleCode().run()}
              disabled={!editor.can().chain().focus().toggleCode().run()}
              className="h-8 w-8 p-0 text-blue-400 hover:text-blue-300 hover:bg-blue-400/10"
            >
              <Code className="h-4 w-4" />
            </Button>
            
            <div className="w-px h-8 bg-gray-700 mx-1" />
            
            {/* Headings */}
            <Button
              size="sm"
              variant={editor.isActive('heading', { level: 1 }) ? 'secondary' : 'ghost'}
              onClick={() => editor.chain().focus().toggleHeading({ level: 1 }).run()}
              className="h-8 w-8 p-0 text-blue-400 hover:text-blue-300 hover:bg-blue-400/10"
            >
              <Heading1 className="h-4 w-4" />
            </Button>
            <Button
              size="sm"
              variant={editor.isActive('heading', { level: 2 }) ? 'secondary' : 'ghost'}
              onClick={() => editor.chain().focus().toggleHeading({ level: 2 }).run()}
              className="h-8 w-8 p-0 text-blue-400 hover:text-blue-300 hover:bg-blue-400/10"
            >
              <Heading2 className="h-4 w-4" />
            </Button>
            <Button
              size="sm"
              variant={editor.isActive('heading', { level: 3 }) ? 'secondary' : 'ghost'}
              onClick={() => editor.chain().focus().toggleHeading({ level: 3 }).run()}
              className="h-8 w-8 p-0 text-blue-400 hover:text-blue-300 hover:bg-blue-400/10"
            >
              <Heading3 className="h-4 w-4" />
            </Button>
            
            <div className="w-px h-8 bg-gray-700 mx-1" />
            
            {/* Lists */}
            <Button
              size="sm"
              variant={editor.isActive('bulletList') ? 'secondary' : 'ghost'}
              onClick={() => editor.chain().focus().toggleBulletList().run()}
              className="h-8 w-8 p-0 text-blue-400 hover:text-blue-300 hover:bg-blue-400/10"
            >
              <List className="h-4 w-4" />
            </Button>
            <Button
              size="sm"
              variant={editor.isActive('orderedList') ? 'secondary' : 'ghost'}
              onClick={() => editor.chain().focus().toggleOrderedList().run()}
              className="h-8 w-8 p-0 text-blue-400 hover:text-blue-300 hover:bg-blue-400/10"
            >
              <ListOrdered className="h-4 w-4" />
            </Button>
            <Button
              size="sm"
              variant={editor.isActive('blockquote') ? 'secondary' : 'ghost'}
              onClick={() => editor.chain().focus().toggleBlockquote().run()}
              className="h-8 w-8 p-0 text-blue-400 hover:text-blue-300 hover:bg-blue-400/10"
            >
              <Quote className="h-4 w-4" />
            </Button>
            
            <div className="w-px h-8 bg-gray-700 mx-1" />
            
            {/* Code block and Horizontal rule */}
            <Button
              size="sm"
              variant={editor.isActive('codeBlock') ? 'secondary' : 'ghost'}
              onClick={() => editor.chain().focus().toggleCodeBlock().run()}
              className="h-8 px-3 text-xs text-blue-400 hover:text-blue-300 hover:bg-blue-400/10"
            >
              Code
            </Button>
            <Button
              size="sm"
              variant="ghost"
              onClick={() => editor.chain().focus().setHorizontalRule().run()}
              className="h-8 px-3 text-xs text-blue-400 hover:text-blue-300 hover:bg-blue-400/10"
            >
              —
            </Button>
            
            <div className="w-px h-8 bg-gray-700 mx-1" />
            
            {/* History */}
            <Button
              size="sm"
              variant="ghost"
              onClick={() => editor.chain().focus().undo().run()}
              disabled={!editor.can().chain().focus().undo().run()}
              className="h-8 w-8 p-0 text-blue-400 hover:text-blue-300 hover:bg-blue-400/10 disabled:text-gray-600"
            >
              <Undo className="h-4 w-4" />
            </Button>
            <Button
              size="sm"
              variant="ghost"
              onClick={() => editor.chain().focus().redo().run()}
              disabled={!editor.can().chain().focus().redo().run()}
              className="h-8 w-8 p-0 text-blue-400 hover:text-blue-300 hover:bg-blue-400/10 disabled:text-gray-600"
            >
              <Redo className="h-4 w-4" />
            </Button>
          </div>
        </div>
      )}
      
      {/* Editor */}
      <div className="flex-1 overflow-auto">
        <EditorContent 
          editor={editor} 
          className="h-full [&_.ProseMirror]:outline-none [&_.ProseMirror]:min-h-[400px] [&_.ProseMirror]:p-3"
        />
      </div>
      

    </div>
  );
}