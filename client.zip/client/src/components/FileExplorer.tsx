import { useState, useEffect, useRef } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { ChevronRight, ChevronDown, FolderPlus, FilePlus, Folder, FileText, MoreVertical, Edit3, Trash2, Upload, AlertTriangle, Move, Image } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from '@/components/ui/dialog';
import { DropdownMenu, DropdownMenuContent, DropdownMenuItem, DropdownMenuTrigger } from '@/components/ui/dropdown-menu';
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle } from '@/components/ui/alert-dialog';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import type { Folder as FolderType, Note, InsertFolder, InsertNote } from '@shared/schema';

interface FileExplorerProps {
  onNoteSelect: (note: Note) => void;
  selectedNote?: Note | null;
}

interface TreeNode {
  id: number;
  name: string;
  type: 'folder' | 'note';
  parentId: number | null;
  children: TreeNode[];
  data: FolderType | Note;
}

export function FileExplorer({ onNoteSelect, selectedNote }: FileExplorerProps) {
  const [expandedFolders, setExpandedFolders] = useState<Set<number>>(new Set([1, 2, 3]));
  const [newFolderName, setNewFolderName] = useState('');
  const [newNoteName, setNewNoteName] = useState('');
  const [editingId, setEditingId] = useState<number | null>(null);
  const [editingName, setEditingName] = useState('');
  const [createFolderParent, setCreateFolderParent] = useState<number | null>(null);
  const [createNoteParent, setCreateNoteParent] = useState<number | null>(null);
  const [duplicateCheck, setDuplicateCheck] = useState<{
    show: boolean;
    duplicates: { file: File; content: string; existingNote: Note }[];
    newFiles: { file: File; content: string }[];
  }>({
    show: false,
    duplicates: [],
    newFiles: []
  });
  const [selectedItems, setSelectedItems] = useState<Set<string>>(new Set());
  const [lastSelectedItem, setLastSelectedItem] = useState<string | null>(null);
  const [draggedItems, setDraggedItems] = useState<Set<string>>(new Set());
  const [dragOver, setDragOver] = useState<string | null>(null);
  const [deleteConfirmation, setDeleteConfirmation] = useState<{
    show: boolean;
    items: string[];
  }>({
    show: false,
    items: []
  });
  const [contextMenu, setContextMenu] = useState<{
    show: boolean;
    x: number;
    y: number;
    node: TreeNode | null;
  }>({
    show: false,
    x: 0,
    y: 0,
    node: null
  });
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const explorerRef = useRef<HTMLDivElement>(null);
  const flatItemsRef = useRef<{ id: string; element: HTMLElement; node: TreeNode }[]>([]);

  const { data: folders = [] } = useQuery<FolderType[]>({
    queryKey: ['/api/folders'],
  });

  const { data: notes = [] } = useQuery<Note[]>({
    queryKey: ['/api/notes'],
  });

  const createFolderMutation = useMutation({
    mutationFn: async (data: InsertFolder) => {
      const response = await apiRequest('POST', '/api/folders', data);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/folders'] });
      setNewFolderName('');
      setCreateFolderParent(null);
      toast({ title: "Folder created successfully!" });
    },
    onError: (error: any) => {
      console.error('Create folder error:', error);
      toast({
        title: "Error",
        description: error.message || "Failed to create folder. Please try again.",
      });
    }
  });

  const createNoteMutation = useMutation({
    mutationFn: async (data: InsertNote) => {
      const response = await apiRequest('POST', '/api/notes', data);
      return response.json();
    },
    onSuccess: () => {
      // Don't invalidate queries here - will be done in batch
      setNewNoteName('');
      setCreateNoteParent(null);
      toast({ title: "Note created successfully!" });
    },
  });

  const updateFolderMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: Partial<InsertFolder> }) => {
      return await apiRequest('PATCH', `/api/folders/${id}`, data);
    },
    onSuccess: (_, { data }) => {
      queryClient.invalidateQueries({ queryKey: ['/api/folders'] });
      queryClient.invalidateQueries({ queryKey: ['/api/notes'] });
      setEditingId(null);
      setEditingName('');
      
      // Auto-expand the target folder if it's a parent change
      if (data.parentId !== undefined && data.parentId !== null) {
        setExpandedFolders(prev => new Set([...prev, data.parentId!]));
      }
      
      toast({ title: "Folder updated successfully!" });
    },
    onError: (error) => {
      console.error('Update folder error:', error);
      toast({
        title: "Error",
        description: "Failed to update folder. Please try again.",
      });
    }
  });

  const updateNoteMutation = useMutation({
    mutationFn: async ({ id, data }: { id: number; data: Partial<InsertNote> }) => {
      const response = await apiRequest('PATCH', `/api/notes/${id}`, data);
      return response;
    },
    onSuccess: (_, { data }) => {
      queryClient.invalidateQueries({ queryKey: ['/api/notes'] });
      setEditingId(null);
      setEditingName('');
      
      // Auto-expand the target folder if it's a folder change
      if (data.folderId !== undefined && data.folderId !== null) {
        setExpandedFolders(prev => new Set([...prev, data.folderId!]));
      }
      
      toast({ title: "Note updated successfully!" });
    },
    onError: (error) => {
      console.error('Update note error:', error);
      toast({
        title: "Error",
        description: "Failed to update note. Please try again.",
      });
    }
  });

  const deleteFolderMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest('DELETE', `/api/folders/${id}`);
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/folders'] });
      toast({ title: "Folder deleted successfully!" });
    },
  });

  const deleteNoteMutation = useMutation({
    mutationFn: async (id: number) => {
      await apiRequest('DELETE', `/api/notes/${id}`);
    },
    onSuccess: () => {
      // Don't invalidate queries here - will be done in batch
      toast({ title: "Note deleted successfully!" });
    },
  });

  const buildTree = (): TreeNode[] => {
    const nodeMap = new Map<string, TreeNode>();
    
    // Add folders to map with string keys to avoid ID conflicts
    folders.forEach(folder => {
      nodeMap.set(`folder-${folder.id}`, {
        id: folder.id,
        name: folder.name,
        type: 'folder',
        parentId: folder.parentId,
        children: [],
        data: folder
      });
    });

    // Add notes to map with string keys to avoid ID conflicts
    notes.forEach(note => {
      nodeMap.set(`note-${note.id}`, {
        id: note.id,
        name: note.title,
        type: 'note',
        parentId: note.folderId,
        children: [],
        data: note
      });
    });

    // Build tree structure
    const rootNodes: TreeNode[] = [];
    
    nodeMap.forEach(node => {
      if (node.parentId === null) {
        rootNodes.push(node);
      } else {
        // Find parent folder
        const parent = nodeMap.get(`folder-${node.parentId}`);
        if (parent) {
          parent.children.push(node);
        } else {
          // If parent folder doesn't exist, add to root
          console.warn(`Parent folder ${node.parentId} not found for ${node.type} ${node.name}`);
          rootNodes.push(node);
        }
      }
    });

    // Sort children
    const sortChildren = (nodes: TreeNode[]) => {
      nodes.sort((a, b) => {
        if (a.type !== b.type) {
          return a.type === 'folder' ? -1 : 1; // Folders first
        }
        return a.name.localeCompare(b.name);
      });
      nodes.forEach(node => sortChildren(node.children));
    };

    sortChildren(rootNodes);
    return rootNodes;
  };

  const toggleFolder = (folderId: number) => {
    setExpandedFolders(prev => {
      const newSet = new Set(prev);
      if (newSet.has(folderId)) {
        newSet.delete(folderId);
      } else {
        newSet.add(folderId);
      }
      return newSet;
    });
  };

  const handleCreateFolder = () => {
    if (newFolderName.trim()) {
      createFolderMutation.mutate({
        name: newFolderName.trim(),
        parentId: createFolderParent === 0 ? null : createFolderParent,
        userId: null // Will be set to actual user ID when OAuth is implemented
      });
    }
  };

  const handleCreateNote = () => {
    if (newNoteName.trim()) {
      createNoteMutation.mutate({
        title: newNoteName.trim(),
        content: '# ' + newNoteName.trim() + '\n\nYour content here...', // Default markdown content
        category: 'general',
        tags: [],
        folderId: createNoteParent === 0 ? null : createNoteParent,
        userId: null, // Will be set to actual user ID when OAuth is implemented
        connections: []
      });
    }
  };

  const handleImport = () => {
    fileInputRef.current?.click();
  };

  const handleFileChange = async (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = Array.from(event.target.files || []);
    const mdFiles = files.filter(file => file.name.endsWith('.md'));
    const imageFiles = files.filter(file => 
      file.type.startsWith('image/') || 
      ['.png', '.jpg', '.jpeg', '.gif', '.webp', '.svg'].some(ext => file.name.toLowerCase().endsWith(ext))
    );
    
    if (mdFiles.length === 0 && imageFiles.length === 0) {
      toast({ 
        title: "No supported files found", 
        description: "Please select .md files or images",
        variant: "destructive"
      });
      return;
    }

    // Process images first
    if (imageFiles.length > 0) {
      await processImageFiles(imageFiles);
    }

    // Then process markdown files
    if (mdFiles.length > 0) {
      await processMarkdownFiles(mdFiles);
    }

    // Reset the input
    event.target.value = '';
  };

  const processImageFiles = async (imageFiles: File[]) => {
    toast({ 
      title: "Uploading images...", 
      description: `Processing ${imageFiles.length} image files`
    });

    let processedCount = 0;
    const totalFiles = imageFiles.length;

    // Disable automatic query invalidation during bulk upload
    queryClient.setQueryDefaults(['/api/notes'], { refetchOnWindowFocus: false });

    for (const file of imageFiles) {
      try {
        // Read file as base64
        const base64 = await new Promise<string>((resolve) => {
          const reader = new FileReader();
          reader.onload = (e) => {
            const result = e.target?.result as string;
            // Extract base64 data (remove data:image/...;base64, prefix)
            const base64Data = result.split(',')[1];
            resolve(base64Data);
          };
          reader.readAsDataURL(file);
        });

        // Create image note using direct API call
        await apiRequest('POST', '/api/notes', {
          title: file.name,
          content: `![${file.name}](image)`, // Placeholder content
          category: 'image',
          tags: ['image', 'imported'],
          folderId: null,
          userId: null,
          connections: [],
          type: 'image',
          imageData: base64,
          mimeType: file.type || 'image/png'
        });

        processedCount++;
        
        if (processedCount % 5 === 0 || processedCount === totalFiles) {
          toast({ 
            title: `Progress: ${processedCount}/${totalFiles}`, 
            description: `Successfully uploaded ${processedCount} images`
          });
        }

        if (processedCount < totalFiles) {
          await new Promise(resolve => setTimeout(resolve, 100));
        }
      } catch (error) {
        console.error(`Failed to process image ${file.name}:`, error);
        toast({ 
          title: "Upload error", 
          description: `Failed to upload ${file.name}`,
          variant: "destructive"
        });
      }
    }

    // Re-enable automatic query invalidation
    queryClient.setQueryDefaults(['/api/notes'], { refetchOnWindowFocus: true });
    
    // Invalidate queries once after all uploads
    queryClient.invalidateQueries({ queryKey: ['/api/notes'] });

    toast({ 
      title: "Image upload completed!", 
      description: `Successfully processed ${processedCount} out of ${totalFiles} images`
    });
  };

  const processMarkdownFiles = async (mdFiles: File[]) => {
    if (mdFiles.length === 0) return;

    toast({ 
      title: "Checking for duplicates...", 
      description: `Analyzing ${mdFiles.length} markdown files`
    });

    // Read all files and check for duplicates
    const fileContents = await Promise.all(
      mdFiles.map(async (file) => {
        const content = await new Promise<string>((resolve) => {
          const reader = new FileReader();
          reader.onload = (e) => resolve(e.target?.result as string);
          reader.readAsText(file);
        });
        return { file, content };
      })
    );

    // Check for duplicates
    const duplicates: { file: File; content: string; existingNote: Note }[] = [];
    const newFiles: { file: File; content: string }[] = [];

    fileContents.forEach(({ file, content }) => {
      const title = file.name.replace('.md', '');
      const existingNote = notes.find(note => note.title.toLowerCase() === title.toLowerCase());
      
      if (existingNote) {
        duplicates.push({ file, content, existingNote });
      } else {
        newFiles.push({ file, content });
      }
    });

    if (duplicates.length > 0) {
      // Show duplicate confirmation dialog
      setDuplicateCheck({
        show: true,
        duplicates,
        newFiles
      });
    } else {
      // No duplicates, proceed with upload
      await processFiles(newFiles);
    }
  };

  const processFiles = async (filesToProcess: { file: File; content: string }[]) => {
    if (filesToProcess.length === 0) {
      toast({ 
        title: "No files to process", 
        description: "All files were skipped"
      });
      return;
    }

    toast({ 
      title: "Uploading files...", 
      description: `Processing ${filesToProcess.length} markdown files`
    });

    let processedCount = 0;
    const totalFiles = filesToProcess.length;

    // Disable automatic query invalidation during bulk upload
    queryClient.setQueryDefaults(['/api/notes'], { refetchOnWindowFocus: false });

    for (const { file, content } of filesToProcess) {
      try {
        const title = file.name.replace('.md', '');
        
        await apiRequest('POST', '/api/notes', {
          title,
          content,
          category: 'imported',
          tags: ['imported'],
          folderId: null,
          userId: null,
          connections: []
        });

        processedCount++;
        
        if (processedCount % 5 === 0 || processedCount === totalFiles) {
          toast({ 
            title: `Progress: ${processedCount}/${totalFiles}`, 
            description: `Successfully uploaded ${processedCount} files`
          });
        }

        if (processedCount < totalFiles) {
          await new Promise(resolve => setTimeout(resolve, 100));
        }
      } catch (error) {
        console.error(`Failed to process file ${file.name}:`, error);
        toast({ 
          title: "Upload error", 
          description: `Failed to upload ${file.name}`,
          variant: "destructive"
        });
      }
    }

    // Re-enable automatic query invalidation
    queryClient.setQueryDefaults(['/api/notes'], { refetchOnWindowFocus: true });
    
    // Invalidate queries once after all uploads
    queryClient.invalidateQueries({ queryKey: ['/api/notes'] });

    toast({ 
      title: "Upload completed!", 
      description: `Successfully processed ${processedCount} out of ${totalFiles} files`
    });
  };

  const handleOverwriteAll = async () => {
    const allFiles = [...duplicateCheck.newFiles, ...duplicateCheck.duplicates];
    
    // First, update/overwrite existing notes
    for (const { file, content, existingNote } of duplicateCheck.duplicates) {
      try {
        await new Promise<void>((resolve, reject) => {
          updateNoteMutation.mutate({
            id: existingNote.id,
            data: { content }
          }, {
            onSuccess: () => resolve(),
            onError: (error) => reject(error)
          });
        });
      } catch (error) {
        console.error(`Failed to update ${file.name}:`, error);
      }
    }
    
    // Then process new files
    await processFiles(duplicateCheck.newFiles);
    
    setDuplicateCheck({ show: false, duplicates: [], newFiles: [] });
  };

  const handleSkipDuplicates = async () => {
    await processFiles(duplicateCheck.newFiles);
    setDuplicateCheck({ show: false, duplicates: [], newFiles: [] });
  };

  const handleCancel = () => {
    setDuplicateCheck({ show: false, duplicates: [], newFiles: [] });
  };

  // Helper function to create unique item IDs
  const getItemId = (node: TreeNode) => {
    return `${node.type}-${node.id}`;
  };

  // Handle item selection
  const handleItemClick = (node: TreeNode, event: React.MouseEvent) => {
    const itemId = getItemId(node);
    
    if (event.ctrlKey || event.metaKey) {
      // Multi-select with Ctrl/Cmd
      setSelectedItems(prev => {
        const newSet = new Set(prev);
        if (newSet.has(itemId)) {
          newSet.delete(itemId);
        } else {
          newSet.add(itemId);
        }
        return newSet;
      });
      setLastSelectedItem(itemId);
    } else if (event.shiftKey && lastSelectedItem) {
      // Range select with Shift
      const startIndex = flatItemsRef.current.findIndex(item => item.id === lastSelectedItem);
      const endIndex = flatItemsRef.current.findIndex(item => item.id === itemId);
      
      if (startIndex !== -1 && endIndex !== -1) {
        const [minIndex, maxIndex] = startIndex < endIndex ? [startIndex, endIndex] : [endIndex, startIndex];
        const rangeItems = flatItemsRef.current.slice(minIndex, maxIndex + 1).map(item => item.id);
        setSelectedItems(prev => new Set([...prev, ...rangeItems]));
      }
    } else {
      // Single select
      setSelectedItems(new Set([itemId]));
      setLastSelectedItem(itemId);
    }
  };

  // Handle click outside to deselect
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (explorerRef.current && !explorerRef.current.contains(event.target as Node)) {
        setSelectedItems(new Set());
        setLastSelectedItem(null);
      }
      // Close context menu
      setContextMenu({ show: false, x: 0, y: 0, node: null });
    };

    document.addEventListener('click', handleClickOutside);
    return () => document.removeEventListener('click', handleClickOutside);
  }, []);

  // Handle click on empty space within the panel to deselect
  const handlePanelClick = (e: React.MouseEvent) => {
    if (e.target === e.currentTarget) {
      setSelectedItems(new Set());
      setLastSelectedItem(null);
    }
    setContextMenu({ show: false, x: 0, y: 0, node: null });
  };

  // Handle drag start
  const handleDragStart = (event: React.DragEvent, node: TreeNode) => {
    const itemId = getItemId(node);
    
    // If the dragged item is not selected, select it
    if (!selectedItems.has(itemId)) {
      setSelectedItems(new Set([itemId]));
      setDraggedItems(new Set([itemId]));
    } else {
      setDraggedItems(new Set(selectedItems));
    }
    
    // Set drag data
    event.dataTransfer.setData('text/plain', JSON.stringify({
      type: 'file-explorer-items',
      items: Array.from(selectedItems.has(itemId) ? selectedItems : [itemId])
    }));
    
    event.dataTransfer.effectAllowed = 'move';
  };

  // Handle drag over
  const handleDragOver = (event: React.DragEvent, node: TreeNode) => {
    event.preventDefault();
    if (node.type === 'folder') {
      setDragOver(getItemId(node));
    }
  };

  // Handle drag leave
  const handleDragLeave = () => {
    setDragOver(null);
  };

  // Handle drop
  const handleDrop = (event: React.DragEvent, targetNode: TreeNode) => {
    event.preventDefault();
    
    try {
      const dragData = JSON.parse(event.dataTransfer.getData('text/plain'));
      
      if (dragData.type === 'file-explorer-items' && targetNode.type === 'folder') {
        const targetFolderId = targetNode.id;
        
        // Auto-expand the target folder to show the moved items
        setExpandedFolders(prev => new Set([...prev, targetFolderId]));
        
        // Move each dragged item with a small delay to prevent race conditions
        dragData.items.forEach((itemId: string, index: number) => {
          setTimeout(() => {
            const [type, id] = itemId.split('-');
            const itemIdNum = parseInt(id);
            
            if (type === 'folder') {
              // Update folder parent
              updateFolderMutation.mutate({
                id: itemIdNum,
                data: { parentId: targetFolderId }
              });
            } else if (type === 'note') {
              // Update note folder
              updateNoteMutation.mutate({
                id: itemIdNum,
                data: { folderId: targetFolderId }
              });
            }
          }, index * 100); // 100ms delay between each item
        });
        
        toast({
          title: "Items moved",
          description: `Successfully moved ${dragData.items.length} item(s) to ${targetNode.name}`
        });
      }
    } catch (error) {
      console.error('Drop error:', error);
    }
    
    setDragOver(null);
    setDraggedItems(new Set());
    setSelectedItems(new Set());
  };

  const handleEdit = (node: TreeNode) => {
    setEditingId(node.type === 'folder' ? node.id : (node.data as Note).id);
    setEditingName(node.name);
  };

  const handleSaveEdit = (node: TreeNode) => {
    if (editingName.trim()) {
      if (node.type === 'folder') {
        updateFolderMutation.mutate({
          id: node.id,
          data: { name: editingName.trim() }
        });
      } else {
        updateNoteMutation.mutate({
          id: (node.data as Note).id,
          data: { title: editingName.trim() }
        });
      }
    }
  };

  const handleDelete = (node: TreeNode) => {
    if (selectedItems.size > 1 && selectedItems.has(getItemId(node))) {
      // Delete multiple selected items
      setDeleteConfirmation({
        show: true,
        items: Array.from(selectedItems)
      });
    } else {
      // Delete single item
      if (node.type === 'folder') {
        deleteFolderMutation.mutate(node.id);
      } else {
        deleteNoteMutation.mutate((node.data as Note).id);
      }
    }
  };

  const handleBulkDelete = async () => {
    const items = deleteConfirmation.items;
    let folderCount = 0;
    let noteCount = 0;

    // Disable automatic query invalidation during bulk operations
    queryClient.setQueryDefaults(['/api/notes'], { refetchOnWindowFocus: false });
    queryClient.setQueryDefaults(['/api/folders'], { refetchOnWindowFocus: false });

    for (const itemId of items) {
      const [type, id] = itemId.split('-');
      const numId = parseInt(id);

      try {
        if (type === 'folder') {
          folderCount++;
          await apiRequest('DELETE', `/api/folders/${numId}`);
        } else if (type === 'note') {
          noteCount++;
          await apiRequest('DELETE', `/api/notes/${numId}`);
        }
        // Add small delay between deletions to prevent overwhelming the server
        await new Promise(resolve => setTimeout(resolve, 100));
      } catch (error) {
        console.error(`Failed to delete ${itemId}:`, error);
      }
    }

    // Re-enable automatic query invalidation
    queryClient.setQueryDefaults(['/api/notes'], { refetchOnWindowFocus: true });
    queryClient.setQueryDefaults(['/api/folders'], { refetchOnWindowFocus: true });

    // Invalidate queries once after all deletions
    queryClient.invalidateQueries({ queryKey: ['/api/notes'] });
    queryClient.invalidateQueries({ queryKey: ['/api/folders'] });

    setSelectedItems(new Set());
    setLastSelectedItem(null);
    setDeleteConfirmation({ show: false, items: [] });
    
    toast({
      title: "Bulk delete completed",
      description: `Deleted ${folderCount} folders and ${noteCount} notes`
    });
  };

  const renderNode = (node: TreeNode, depth: number = 0) => {
    const isExpanded = expandedFolders.has(node.id);
    const isSelected = selectedNote && node.type === 'note' && (node.data as Note).id === selectedNote.id;
    const isEditing = editingId === (node.type === 'folder' ? node.id : (node.data as Note).id);
    const itemId = getItemId(node);
    const isItemSelected = selectedItems.has(itemId);
    const isDraggedOver = dragOver === itemId;

    return (
      <div key={itemId} className="select-none">
        <div
          ref={(el) => {
            if (el) {
              flatItemsRef.current = flatItemsRef.current.filter(item => item.id !== itemId);
              flatItemsRef.current.push({ id: itemId, element: el, node });
            }
          }}
          className={`group flex items-center py-1 px-2 rounded-md cursor-pointer transition-colors ${
            isSelected ? 'bg-[var(--electric-blue)]/20 border-l-2 border-[var(--electric-blue)]' : ''
          } ${
            isItemSelected ? 'bg-yellow-500/20 border-l-2 border-yellow-500' : ''
          } ${
            isDraggedOver ? 'bg-green-500/20 border-2 border-green-500' : ''
          } ${
            !isSelected && !isItemSelected && !isDraggedOver ? 'hover:bg-gray-800/50' : ''
          }`}
          style={{ paddingLeft: `${depth * 16 + 8}px` }}
          onClick={(e) => {
            e.stopPropagation();
            if (e.ctrlKey || e.metaKey || e.shiftKey) {
              handleItemClick(node, e);
            } else {
              handleItemClick(node, e);
              if (node.type === 'folder') {
                toggleFolder(node.id);
              } else {
                onNoteSelect(node.data as Note);
              }
            }
          }}
          onContextMenu={(e) => {
            e.preventDefault();
            e.stopPropagation();
            // If this item is not selected, select it first
            if (!selectedItems.has(itemId)) {
              setSelectedItems(new Set([itemId]));
              setLastSelectedItem(itemId);
            }
            setContextMenu({
              show: true,
              x: e.clientX,
              y: e.clientY,
              node: node
            });
          }}
          draggable={true}
          onDragStart={(e) => {
            e.stopPropagation();
            handleDragStart(e, node);
          }}
          onDragOver={(e) => {
            e.stopPropagation();
            handleDragOver(e, node);
          }}
          onDragLeave={(e) => {
            e.stopPropagation();
            handleDragLeave();
          }}
          onDrop={(e) => {
            e.stopPropagation();
            handleDrop(e, node);
          }}
        >
          {node.type === 'folder' && (
            <div className="mr-1 text-gray-400">
              {isExpanded ? <ChevronDown size={16} /> : <ChevronRight size={16} />}
            </div>
          )}
          
          <div className="mr-2 text-gray-400">
            {node.type === 'folder' ? (
              <Folder size={16} />
            ) : (
              (node.data as Note).type === 'image' ? <Image size={16} /> : <FileText size={16} />
            )}
          </div>

          {isEditing ? (
            <Input
              value={editingName}
              onChange={(e) => setEditingName(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter') {
                  handleSaveEdit(node);
                } else if (e.key === 'Escape') {
                  setEditingId(null);
                  setEditingName('');
                }
              }}
              onBlur={() => handleSaveEdit(node)}
              className="flex-1 h-6 px-2 text-sm bg-gray-800 border-gray-600 text-white"
              autoFocus
            />
          ) : (
            <span className="flex-1 text-sm text-gray-300 truncate">{node.name}</span>
          )}

          <DropdownMenu>
            <DropdownMenuTrigger asChild>
              <Button variant="ghost" size="sm" className="h-6 w-6 p-0 opacity-0 group-hover:opacity-100 hover:bg-gray-700 text-gray-300">
                <MoreVertical size={12} />
              </Button>
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="bg-gray-800 border-gray-700">
              <DropdownMenuItem
                onClick={(e) => {
                  e.stopPropagation();
                  handleEdit(node);
                }}
                className="text-gray-300 hover:bg-gray-700"
              >
                <Edit3 size={14} className="mr-2" />
                Rename
              </DropdownMenuItem>
              {node.type === 'folder' && (
                <>
                  <DropdownMenuItem
                    onClick={(e) => {
                      e.stopPropagation();
                      setCreateFolderParent(node.id);
                    }}
                    className="text-gray-300 hover:bg-gray-700"
                  >
                    <FolderPlus size={14} className="mr-2" />
                    New Folder
                  </DropdownMenuItem>
                  <DropdownMenuItem
                    onClick={(e) => {
                      e.stopPropagation();
                      setCreateNoteParent(node.id);
                    }}
                    className="text-gray-300 hover:bg-gray-700"
                  >
                    <FilePlus size={14} className="mr-2" />
                    New Note
                  </DropdownMenuItem>
                </>
              )}
              <DropdownMenuItem
                onClick={(e) => {
                  e.stopPropagation();
                  handleDelete(node);
                }}
                className="text-red-400 hover:bg-red-900/20"
              >
                <Trash2 size={14} className="mr-2" />
                Delete {selectedItems.size > 1 && selectedItems.has(getItemId(node)) ? `(${selectedItems.size} items)` : ''}
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>
        </div>

        {node.type === 'folder' && isExpanded && (
          <div>
            {node.children.map(child => renderNode(child, depth + 1))}
          </div>
        )}
      </div>
    );
  };

  const tree = buildTree();

  return (
    <div ref={explorerRef} className="w-80 h-full bg-gray-900/95 border-r border-gray-700/50 backdrop-blur-sm flex flex-col">
      {/* Header */}
      <div className="p-4 border-b border-gray-700/50">
        <div className="flex items-center justify-between mb-3">
          <h2 className="text-lg font-semibold text-[var(--electric-blue)] glowing-text">
            Knowledge Base
          </h2>
          <div className="flex gap-1">
            {selectedItems.size > 0 && (
              <span className="text-xs text-gray-400 mr-2">
                {selectedItems.size} selected
              </span>
            )}
            <Button
              size="sm"
              variant="ghost"
              onClick={handleImport}
              className="h-8 w-8 p-0 text-gray-400 hover:text-white hover:bg-gray-700"
              title="Import .md file"
            >
              <Upload size={16} />
            </Button>
            <Button
              size="sm"
              variant="ghost"
              onClick={() => setCreateFolderParent(0)}
              className="h-8 w-8 p-0 text-gray-400 hover:text-white hover:bg-gray-700"
              title="New folder"
            >
              <FolderPlus size={16} />
            </Button>
            <Button
              size="sm"
              variant="ghost"
              onClick={() => setCreateNoteParent(0)}
              className="h-8 w-8 p-0 text-gray-400 hover:text-white hover:bg-gray-700"
              title="New note"
            >
              <FilePlus size={16} />
            </Button>
          </div>
        </div>
        
        {/* Instructions */}
        <div className="text-xs text-gray-500 mt-2">
          {selectedItems.size > 0 ? (
            <>
              <div className="text-yellow-400 font-medium mb-1">
                {selectedItems.size} items selected
              </div>
              <div>• Ctrl+Click to add/remove items</div>
              <div>• Shift+Click for range selection</div>
              <div>• Right-click or use menu to delete</div>
              <div>• Click outside to clear selection</div>
            </>
          ) : (
            <>
              <div>• Ctrl+Click to select multiple items</div>
              <div>• Shift+Click for range selection</div>
              <div>• Drag items to reorganize structure</div>
            </>
          )}
        </div>
      </div>

      {/* File Tree */}
      <div 
        className="flex-1 overflow-y-auto scrollbar-thin p-2"
        onClick={handlePanelClick}
        onDragOver={(e) => {
          e.preventDefault();
          setDragOver('root');
        }}
        onDragLeave={(e) => {
          if (!e.currentTarget.contains(e.relatedTarget as Node)) {
            setDragOver(null);
          }
        }}
        onDrop={(e) => {
          e.preventDefault();
          try {
            const dragData = JSON.parse(e.dataTransfer.getData('text/plain'));
            
            if (dragData.type === 'file-explorer-items') {
              // Move items to root with a small delay to prevent race conditions
              dragData.items.forEach((itemId: string, index: number) => {
                setTimeout(() => {
                  const [type, id] = itemId.split('-');
                  const itemIdNum = parseInt(id);
                  
                  if (type === 'folder') {
                    updateFolderMutation.mutate({
                      id: itemIdNum,
                      data: { parentId: null }
                    });
                  } else if (type === 'note') {
                    updateNoteMutation.mutate({
                      id: itemIdNum,
                      data: { folderId: null }
                    });
                  }
                }, index * 100); // 100ms delay between each item
              });
              
              toast({
                title: "Items moved",
                description: `Successfully moved ${dragData.items.length} item(s) to root`
              });
            }
          } catch (error) {
            console.error('Root drop error:', error);
          }
          
          setDragOver(null);
          setDraggedItems(new Set());
          setSelectedItems(new Set());
        }}
      >
        <div className={`transition-colors ${dragOver === 'root' ? 'bg-green-500/10 border-2 border-green-500 rounded' : ''}`}>
          {tree.map(node => renderNode(node))}
        </div>
      </div>

      {/* Create Folder Dialog */}
      <Dialog open={createFolderParent !== null} onOpenChange={() => setCreateFolderParent(null)}>
        <DialogContent className="bg-gray-800 border-gray-700">
          <DialogHeader>
            <DialogTitle className="text-white">Create New Folder</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <Input
              placeholder="Folder name"
              value={newFolderName}
              onChange={(e) => setNewFolderName(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleCreateFolder()}
              className="bg-gray-700 border-gray-600 text-white"
            />
            <div className="flex gap-2">
              <Button
                onClick={handleCreateFolder}
                disabled={!newFolderName.trim() || createFolderMutation.isPending}
                className="bg-[var(--electric-blue)] hover:bg-[var(--electric-blue)]/80"
              >
                Create
              </Button>
              <Button
                variant="outline"
                onClick={() => setCreateFolderParent(null)}
                className="border-gray-600 text-gray-300 hover:bg-gray-700"
              >
                Cancel
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Create Note Dialog */}
      <Dialog open={createNoteParent !== null} onOpenChange={() => setCreateNoteParent(null)}>
        <DialogContent className="bg-gray-800 border-gray-700">
          <DialogHeader>
            <DialogTitle className="text-white">Create New Note</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <Input
              placeholder="Note title"
              value={newNoteName}
              onChange={(e) => setNewNoteName(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && handleCreateNote()}
              className="bg-gray-700 border-gray-600 text-white"
            />
            <div className="flex gap-2">
              <Button
                onClick={handleCreateNote}
                disabled={!newNoteName.trim() || createNoteMutation.isPending}
                className="bg-[var(--electric-blue)] hover:bg-[var(--electric-blue)]/80"
              >
                Create
              </Button>
              <Button
                variant="outline"
                onClick={() => setCreateNoteParent(null)}
                className="border-gray-600 text-gray-300 hover:bg-gray-700"
              >
                Cancel
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Duplicate File Confirmation Dialog */}
      <AlertDialog open={duplicateCheck.show} onOpenChange={() => setDuplicateCheck({ show: false, duplicates: [], newFiles: [] })}>
        <AlertDialogContent className="bg-gray-800 border-gray-700">
          <AlertDialogHeader>
            <AlertDialogTitle className="text-white flex items-center gap-2">
              <AlertTriangle className="w-5 h-5 text-yellow-500" />
              Duplicate Files Found
            </AlertDialogTitle>
            <AlertDialogDescription className="text-gray-300">
              {duplicateCheck.duplicates.length} file(s) already exist with the same name:
              <div className="mt-2 space-y-1">
                {duplicateCheck.duplicates.map(({ file, existingNote }) => (
                  <div key={file.name} className="text-sm text-gray-400 bg-gray-700 px-2 py-1 rounded">
                    📄 {file.name} → {existingNote.title}
                  </div>
                ))}
              </div>
              {duplicateCheck.newFiles.length > 0 && (
                <div className="mt-2">
                  {duplicateCheck.newFiles.length} new file(s) will be imported.
                </div>
              )}
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel 
              onClick={handleCancel}
              className="bg-gray-700 border-gray-600 text-gray-300 hover:bg-gray-600"
            >
              Cancel
            </AlertDialogCancel>
            <AlertDialogAction 
              onClick={handleSkipDuplicates}
              className="bg-blue-600 hover:bg-blue-700"
            >
              Skip Duplicates
            </AlertDialogAction>
            <AlertDialogAction 
              onClick={handleOverwriteAll}
              className="bg-orange-600 hover:bg-orange-700"
            >
              Overwrite All
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Bulk Delete Confirmation Dialog */}
      <AlertDialog open={deleteConfirmation.show} onOpenChange={() => setDeleteConfirmation({ show: false, items: [] })}>
        <AlertDialogContent className="bg-gray-800 border-gray-700">
          <AlertDialogHeader>
            <AlertDialogTitle className="text-white flex items-center gap-2">
              <Trash2 className="w-5 h-5 text-red-500" />
              Delete Multiple Items
            </AlertDialogTitle>
            <AlertDialogDescription className="text-gray-300">
              Are you sure you want to delete {deleteConfirmation.items.length} selected items?
              <div className="mt-3 max-h-40 overflow-y-auto space-y-1">
                {deleteConfirmation.items.map(itemId => {
                  const [type, id] = itemId.split('-');
                  const node = flatItemsRef.current.find(item => item.id === itemId)?.node;
                  return (
                    <div key={itemId} className="text-sm text-gray-400 bg-gray-700 px-2 py-1 rounded flex items-center gap-2">
                      {type === 'folder' ? <Folder size={14} /> : <FileText size={14} />}
                      {node?.name || itemId}
                    </div>
                  );
                })}
              </div>
              <div className="mt-3 text-sm text-red-400">
                This action cannot be undone.
              </div>
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter>
            <AlertDialogCancel 
              onClick={() => setDeleteConfirmation({ show: false, items: [] })}
              className="bg-gray-700 border-gray-600 text-gray-300 hover:bg-gray-600"
            >
              Cancel
            </AlertDialogCancel>
            <AlertDialogAction 
              onClick={handleBulkDelete}
              className="bg-red-600 hover:bg-red-700"
            >
              Delete All
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>

      {/* Right-click context menu */}
      {contextMenu.show && contextMenu.node && (
        <div
          className="fixed z-50 bg-gray-800 border border-gray-700 rounded-md shadow-lg min-w-[160px]"
          style={{
            left: contextMenu.x,
            top: contextMenu.y,
          }}
          onClick={(e) => e.stopPropagation()}
        >
          <div className="py-1">
            <button
              onClick={(e) => {
                e.stopPropagation();
                handleEdit(contextMenu.node!);
                setContextMenu({ show: false, x: 0, y: 0, node: null });
              }}
              className="flex items-center w-full px-3 py-2 text-sm text-gray-300 hover:bg-gray-700"
            >
              <Edit3 size={14} className="mr-2" />
              Rename
            </button>
            {contextMenu.node.type === 'folder' && (
              <>
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    setCreateFolderParent(contextMenu.node!.id);
                    setContextMenu({ show: false, x: 0, y: 0, node: null });
                  }}
                  className="flex items-center w-full px-3 py-2 text-sm text-gray-300 hover:bg-gray-700"
                >
                  <FolderPlus size={14} className="mr-2" />
                  New Folder
                </button>
                <button
                  onClick={(e) => {
                    e.stopPropagation();
                    setCreateNoteParent(contextMenu.node!.id);
                    setContextMenu({ show: false, x: 0, y: 0, node: null });
                  }}
                  className="flex items-center w-full px-3 py-2 text-sm text-gray-300 hover:bg-gray-700"
                >
                  <FilePlus size={14} className="mr-2" />
                  New Note
                </button>
              </>
            )}
            <button
              onClick={(e) => {
                e.stopPropagation();
                handleDelete(contextMenu.node!);
                setContextMenu({ show: false, x: 0, y: 0, node: null });
              }}
              className="flex items-center w-full px-3 py-2 text-sm text-red-400 hover:bg-red-900/20"
            >
              <Trash2 size={14} className="mr-2" />
              Delete {selectedItems.size > 1 && selectedItems.has(getItemId(contextMenu.node)) ? `(${selectedItems.size} items)` : ''}
            </button>
          </div>
        </div>
      )}

      {/* Hidden file input for import */}
      <input
        type="file"
        ref={fileInputRef}
        onChange={handleFileChange}
        accept=".md"
        multiple
        style={{ display: 'none' }}
      />
    </div>
  );
}