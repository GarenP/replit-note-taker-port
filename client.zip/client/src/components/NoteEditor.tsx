import { TiptapEditor } from '@/components/TiptapEditor';
import type { Note } from '@shared/schema';

interface NoteEditorProps {
  content: string;
  onSave: (content: string) => void;
  isReadOnly?: boolean;
  imageNotes: Map<string, Note>;
  findNoteByTitle: (title: string) => Note | undefined;
  onWikiLinkClick: (title: string) => void;
}

export function NoteEditor({ 
  content, 
  onSave, 
  isReadOnly = false,
  imageNotes,
  findNoteByTitle,
  onWikiLinkClick 
}: NoteEditorProps) {
  return (
    <div className="h-full">
      <TiptapEditor
        content={content}
        onSave={onSave}
        isReadOnly={isReadOnly}
        imageNotes={imageNotes}
        findNoteByTitle={findNoteByTitle}
        onWikiLinkClick={onWikiLinkClick}
      />
    </div>
  );
}