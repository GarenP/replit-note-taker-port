import { X, ChevronLeft, ChevronRight } from 'lucide-react';
import { format } from 'date-fns';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import ReactMarkdown from 'react-markdown';
import remarkGfm from 'remark-gfm';
import rehypeRaw from 'rehype-raw';
import { remarkWikiLink } from '@/lib/remarkWikiLink';
import { remarkImageEmbed } from '@/lib/remarkImageEmbed';
import { remarkNoteEmbed } from '@/lib/remarkNoteEmbed';
import { NoteEditor } from '@/components/NoteEditor';
import { useQuery, useQueryClient, useMutation } from '@tanstack/react-query';
import { apiRequest } from '@/lib/queryClient';
import { useState, useEffect, useRef } from 'react';
import type { Note } from '@shared/schema';

interface NotePreviewProps {
  note: Note;
  onClose: () => void;
  onNoteSelect?: (note: Note) => void;
  initialPosition?: { x: number; y: number };
  initialSize?: { width: number; height: number };
  onPositionChange?: (position: { x: number; y: number }) => void;
  onSizeChange?: (size: { width: number; height: number }) => void;
}

export function NotePreview({ 
  note, 
  onClose, 
  onNoteSelect,
  initialPosition = { x: 100, y: 100 },
  initialSize = { width: 500, height: 600 },
  onPositionChange,
  onSizeChange
}: NotePreviewProps) {
  const [noteHistory, setNoteHistory] = useState<Note[]>([note]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [position, setPosition] = useState(initialPosition);
  const [size, setSize] = useState(initialSize);

  const [isHoveringLink, setIsHoveringLink] = useState(false);
  const [editedContent, setEditedContent] = useState(note.content);
  const [imageNotes, setImageNotes] = useState<Map<string, Note>>(new Map());
  const [inlineEditMode, setInlineEditMode] = useState(false);
  const [editingEmbedId, setEditingEmbedId] = useState<string | null>(null);
  const contentRef = useRef<HTMLDivElement>(null);
  
  // Ensure window stays within viewport bounds on initial render and when size changes
  useEffect(() => {
    const constrainedX = Math.max(0, Math.min(window.innerWidth - size.width, position.x));
    const constrainedY = Math.max(0, Math.min(window.innerHeight - size.height, position.y));
    
    if (constrainedX !== position.x || constrainedY !== position.y) {
      setPosition({ x: constrainedX, y: constrainedY });
    }
  }, [size.width, size.height]);
  const [isDragging, setIsDragging] = useState(false);
  const [isResizing, setIsResizing] = useState(false);
  const [resizeHandle, setResizeHandle] = useState<string>('');
  const [dragStart, setDragStart] = useState({ x: 0, y: 0 });
  const [resizeStart, setResizeStart] = useState({ x: 0, y: 0, width: 0, height: 0, initialX: 0, initialY: 0 });
  const queryClient = useQueryClient();
  
  // Fetch all notes for wiki link and image embed functionality
  const { data: allNotes = [] } = useQuery<Note[]>({
    queryKey: ['/api/notes'],
  });
  
  // Use refs to store the current state for event handlers
  const positionRef = useRef(position);
  const sizeRef = useRef(size);
  const dragStartRef = useRef(dragStart);
  const resizeStartRef = useRef(resizeStart);
  const resizeHandleRef = useRef(resizeHandle);
  
  // Update refs when state changes
  useEffect(() => {
    positionRef.current = position;
    sizeRef.current = size;
    dragStartRef.current = dragStart;
    resizeStartRef.current = resizeStart;
    resizeHandleRef.current = resizeHandle;
  }, [position, size, dragStart, resizeStart, resizeHandle]);
  
  const currentNote = noteHistory[currentIndex] || note;

  // Update history when note changes externally (not from navigation)
  useEffect(() => {
    // Only reset history if this note is not already in the current position
    if (!noteHistory[currentIndex] || noteHistory[currentIndex].id !== note.id) {
      // If we're not at the end of history, truncate future history
      const newHistory = [...noteHistory.slice(0, currentIndex + 1), note];
      setNoteHistory(newHistory);
      setCurrentIndex(newHistory.length - 1);
    }
    setEditedContent(note.content);
  }, [note.id]);

  // Update edited content when current note changes
  useEffect(() => {
    setEditedContent(currentNote.content);
  }, [currentNote.content]);

  // Load image notes referenced in content
  useEffect(() => {
    const imageEmbedRegex = /!\[\[([^\]]+)\]\]/g;
    const matches = Array.from(currentNote.content.matchAll(imageEmbedRegex));
    const imageTitles = matches.map(match => match[1].trim());
    
    const newImageNotes = new Map<string, Note>();
    imageTitles.forEach(title => {
      const imageNote = findNoteByTitle(title);
      if (imageNote && imageNote.type === 'image') {
        newImageNotes.set(title, imageNote);
      }
    });
    
    setImageNotes(newImageNotes);
  }, [currentNote.content, allNotes]);

  const canGoBack = currentIndex > 0;
  const canGoForward = currentIndex < noteHistory.length - 1;

  const goBack = () => {
    if (canGoBack) {
      const newIndex = currentIndex - 1;
      setCurrentIndex(newIndex);
      if (onNoteSelect) {
        onNoteSelect(noteHistory[newIndex]);
      }
    }
  };

  const goForward = () => {
    if (canGoForward) {
      const newIndex = currentIndex + 1;
      setCurrentIndex(newIndex);
      if (onNoteSelect) {
        onNoteSelect(noteHistory[newIndex]);
      }
    }
  };

  // Update note mutation
  const updateNoteMutation = useMutation({
    mutationFn: async (data: { id: number; content: string }) => {
      return apiRequest('PATCH', `/api/notes/${data.id}`, { content: data.content });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['/api/notes'] });
      setEditMode(false);
    },
  });

  // Save edited content
  const saveNote = () => {
    if (editedContent !== currentNote.content) {
      updateNoteMutation.mutate({ id: currentNote.id, content: editedContent });
    } else {
      setEditMode(false);
    }
  };

  // Function to find note by title for wiki links
  const findNoteByTitle = (title: string): Note | undefined => {
    // Decode URL encoded strings and trim whitespace
    const decodedTitle = decodeURIComponent(title).trim();
    const found = allNotes.find(n => 
      n.title.trim().toLowerCase() === decodedTitle.toLowerCase()
    );
    return found;
  };

  // Process note embeds directly in the content
  const processEmbeddedNotes = (content: string): string => {
    const noteEmbedRegex = /!\[\[([^\]]+)\]\]/g;
    let embedIndex = 0;
    
    return content.replace(noteEmbedRegex, (match, noteTitle) => {
      const currentEmbedId = `embed-${embedIndex++}`;
      const embeddedNote = findNoteByTitle(noteTitle.trim());
      
      // If we're editing this specific embed, show the raw syntax
      if (editingEmbedId === currentEmbedId) {
        return `<div class="editing-embed" data-embed-id="${currentEmbedId}" data-original-syntax="${match.replace(/"/g, '&quot;')}">${match}</div>`;
      }
      
      if (embeddedNote) {
        // For image notes, create a special marker
        if (embeddedNote.type === 'image') {
          return `\n\n<div class="embedded-image" data-embed-id="${currentEmbedId}" data-original-syntax="${match.replace(/"/g, '&quot;')}" data-note-title="${embeddedNote.title.replace(/"/g, '&quot;')}" data-image-data="${embeddedNote.imageData}" data-mime-type="${embeddedNote.mimeType}"></div>\n\n`;
        }
        // For text notes, use a div with blue border instead of blockquote to avoid italic
        return `\n\n<div class="embedded-note" data-embed-id="${currentEmbedId}" data-original-syntax="${match.replace(/"/g, '&quot;')}" data-note-title="${embeddedNote.title}">\n\n**${embeddedNote.title}**\n\n${embeddedNote.content}\n\n</div>\n\n`;
      }
      return match; // Return original if note not found
    });
  };

  // Handle wiki link clicks
  const handleWikiLinkClick = (title: string) => {
    const targetNote = findNoteByTitle(title);
    if (targetNote && onNoteSelect) {
      // Add to history and navigate
      const newHistory = [...noteHistory.slice(0, currentIndex + 1), targetNote];
      setNoteHistory(newHistory);
      setCurrentIndex(newHistory.length - 1);
      onNoteSelect(targetNote);
    } else {
      // Auto-create note if it doesn't exist
      createNewNote(title);
    }
  };

  // Function to create a new note
  const createNewNote = async (title: string) => {
    try {
      const response = await fetch('/api/notes', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          title: title.trim(),
          content: `# ${title.trim()}\n\nThis note was auto-created from a wiki link.`,
          tags: [],
          category: 'general',
          folderId: null,
          connections: []
        }),
      });

      if (response.ok) {
        const newNote = await response.json();
        // Invalidate the notes cache to refresh the list
        queryClient.invalidateQueries({ queryKey: ['/api/notes'] });
        
        // Navigate to the new note
        if (onNoteSelect) {
          const newHistory = [...noteHistory.slice(0, currentIndex + 1), newNote];
          setNoteHistory(newHistory);
          setCurrentIndex(newHistory.length - 1);
          onNoteSelect(newNote);
        }
      }
    } catch (error) {
      // Handle error silently or show user feedback
    }
  };
  const categoryColors: Record<string, string> = {
    philosophy: '#FF6B6B',
    science: '#4ECDC4',
    history: '#45B7D1',
    art: '#96CEB4',
    literature: '#FFEEAD',
    psychology: '#D4A5A5',
    technology: '#9B59B6',
    mathematics: '#3498DB',
    biology: '#2ECC71',
    physics: '#E74C3C',
    business: '#FF6B6B'
  };

  const getTagColor = (tag: string): string => {
    // Map common tags to categories
    const tagToCategory: Record<string, string> = {
      business: 'business',
      wealth: 'business',
      marketing: 'business',
      psychology: 'psychology',
      mindset: 'psychology',
      productivity: 'psychology',
      philosophy: 'philosophy',
      biology: 'biology',
      neuroscience: 'biology',
      art: 'art',
      creativity: 'art',
      science: 'science',
      technology: 'technology',
      leadership: 'business',
      strategy: 'business',
      influence: 'psychology',
      habits: 'psychology',
      behavior: 'psychology'
    };

    const category = tagToCategory[tag] || 'science';
    return categoryColors[category] || '#ffffff';
  };

  // Handle mouse events for dragging and resizing
  const handleMouseDown = (e: React.MouseEvent, action: 'drag' | 'resize', handle?: string) => {
    e.preventDefault();
    e.stopPropagation();
    
    if (action === 'drag') {
      setIsDragging(true);
      setDragStart({
        x: e.clientX - position.x,
        y: e.clientY - position.y
      });
    } else if (action === 'resize') {
      setIsResizing(true);
      setResizeHandle(handle || '');
      setResizeStart({
        x: e.clientX,
        y: e.clientY,
        width: size.width,
        height: size.height,
        initialX: position.x,
        initialY: position.y
      });
    }
  };

  const handleMouseMove = (e: MouseEvent) => {
    if (isDragging) {
      // Constrain drag to viewport boundaries - keep entire window visible
      const newX = Math.max(0, Math.min(window.innerWidth - sizeRef.current.width, e.clientX - dragStartRef.current.x));
      const newY = Math.max(0, Math.min(window.innerHeight - sizeRef.current.height, e.clientY - dragStartRef.current.y));
      
      setPosition({ x: newX, y: newY });
      
      // Notify parent of position change
      if (onPositionChange) onPositionChange({ x: newX, y: newY });
    } else if (isResizing) {
      const resizeData = resizeStartRef.current;
      const handle = resizeHandleRef.current;
      const deltaX = e.clientX - resizeData.x;
      const deltaY = e.clientY - resizeData.y;
      
      let newWidth = resizeData.width;
      let newHeight = resizeData.height;
      let newX = resizeData.initialX;
      let newY = resizeData.initialY;
      
      // Right edge resize - anchor left side
      if (handle.includes('right')) {
        newWidth = Math.max(300, Math.min(window.innerWidth - resizeData.initialX, resizeData.width + deltaX));
      }
      
      // Left edge resize - anchor right side, adjust position
      if (handle.includes('left')) {
        const rightEdge = resizeData.initialX + resizeData.width;
        newWidth = Math.max(300, resizeData.width - deltaX);
        newX = rightEdge - newWidth;
        
        // Constrain to viewport
        if (newX < 0) {
          newX = 0;
          newWidth = rightEdge;
        }
      }
      
      // Bottom edge resize - anchor top side
      if (handle.includes('bottom')) {
        newHeight = Math.max(400, Math.min(window.innerHeight - resizeData.initialY, resizeData.height + deltaY));
      }
      
      // Top edge resize - anchor bottom side, adjust position  
      if (handle.includes('top')) {
        const bottomEdge = resizeData.initialY + resizeData.height;
        newHeight = Math.max(400, resizeData.height - deltaY);
        newY = bottomEdge - newHeight;
        
        // Constrain to viewport
        if (newY < 0) {
          newY = 0;
          newHeight = bottomEdge;
        }
      }
      
      setSize({ width: newWidth, height: newHeight });
      setPosition({ x: newX, y: newY });
      
      // Notify parent of changes
      if (onSizeChange) onSizeChange({ width: newWidth, height: newHeight });
      if (onPositionChange) onPositionChange({ x: newX, y: newY });
    }
  };

  const handleMouseUp = () => {
    setIsDragging(false);
    setIsResizing(false);
    setResizeHandle('');
  };

  // Add global event listeners for mouse move and up
  useEffect(() => {
    if (isDragging || isResizing) {
      document.addEventListener('mousemove', handleMouseMove);
      document.addEventListener('mouseup', handleMouseUp);
      
      return () => {
        document.removeEventListener('mousemove', handleMouseMove);
        document.removeEventListener('mouseup', handleMouseUp);
      };
    }
  }, [isDragging, isResizing]);

  return (
    <div 
      className="fixed bg-gray-900 border border-gray-700 rounded-lg shadow-2xl flex flex-col overflow-hidden"
      style={{
        left: position.x,
        top: position.y,
        width: size.width,
        height: size.height,
        minWidth: 300,
        minHeight: 400,
        zIndex: 9999
      }}
    >
      {/* Resize handles */}
      <div className="absolute inset-0 pointer-events-none">
        {/* Corner handles */}
        <div 
          className="absolute w-3 h-3 cursor-nw-resize pointer-events-auto opacity-0 hover:opacity-100 transition-opacity"
          style={{ top: -1, left: -1, backgroundColor: 'rgba(59, 130, 246, 0.5)' }}
          onMouseDown={(e) => handleMouseDown(e, 'resize', 'top-left')}
        />
        <div 
          className="absolute w-3 h-3 cursor-ne-resize pointer-events-auto opacity-0 hover:opacity-100 transition-opacity"
          style={{ top: -1, right: -1, backgroundColor: 'rgba(59, 130, 246, 0.5)' }}
          onMouseDown={(e) => handleMouseDown(e, 'resize', 'top-right')}
        />
        <div 
          className="absolute w-3 h-3 cursor-sw-resize pointer-events-auto opacity-0 hover:opacity-100 transition-opacity"
          style={{ bottom: -1, left: -1, backgroundColor: 'rgba(59, 130, 246, 0.5)' }}
          onMouseDown={(e) => handleMouseDown(e, 'resize', 'bottom-left')}
        />
        <div 
          className="absolute w-3 h-3 cursor-se-resize pointer-events-auto opacity-0 hover:opacity-100 transition-opacity"
          style={{ bottom: -1, right: -1, backgroundColor: 'rgba(59, 130, 246, 0.5)' }}
          onMouseDown={(e) => handleMouseDown(e, 'resize', 'bottom-right')}
        />
        
        {/* Edge handles */}
        <div 
          className="absolute h-2 cursor-n-resize pointer-events-auto opacity-0 hover:opacity-100 transition-opacity"
          style={{ top: -1, left: 10, right: 10, backgroundColor: 'rgba(59, 130, 246, 0.3)' }}
          onMouseDown={(e) => handleMouseDown(e, 'resize', 'top')}
        />
        <div 
          className="absolute h-2 cursor-s-resize pointer-events-auto opacity-0 hover:opacity-100 transition-opacity"
          style={{ bottom: -1, left: 10, right: 10, backgroundColor: 'rgba(59, 130, 246, 0.3)' }}
          onMouseDown={(e) => handleMouseDown(e, 'resize', 'bottom')}
        />
        <div 
          className="absolute w-2 cursor-w-resize pointer-events-auto opacity-0 hover:opacity-100 transition-opacity"
          style={{ left: -1, top: 10, bottom: 10, backgroundColor: 'rgba(59, 130, 246, 0.3)' }}
          onMouseDown={(e) => handleMouseDown(e, 'resize', 'left')}
        />
        <div 
          className="absolute w-2 cursor-e-resize pointer-events-auto opacity-0 hover:opacity-100 transition-opacity"
          style={{ right: -1, top: 10, bottom: 10, backgroundColor: 'rgba(59, 130, 246, 0.3)' }}
          onMouseDown={(e) => handleMouseDown(e, 'resize', 'right')}
        />
      </div>
      
      {/* Header with drag handle */}
      <div 
        className="flex items-center justify-between px-2 py-1 border-b border-gray-700 cursor-move select-none bg-gray-800 hover:bg-gray-750 transition-colors"
        onMouseDown={(e) => handleMouseDown(e, 'drag')}
      >
        <div className="flex items-center gap-1">
          <Button
            variant="ghost"
            size="sm"
            onClick={goBack}
            disabled={!canGoBack}
            className="p-1 h-6 w-6 hover:bg-gray-700 text-gray-300 disabled:text-gray-600"
          >
            <ChevronLeft className="h-3 w-3" />
          </Button>
          <Button
            variant="ghost"
            size="sm"
            onClick={goForward}
            disabled={!canGoForward}
            className="p-1 h-6 w-6 hover:bg-gray-700 text-gray-300 disabled:text-gray-600"
          >
            <ChevronRight className="h-3 w-3" />
          </Button>
        </div>
        <div className="flex items-center">
          <Button
            variant="ghost"
            size="sm"
            onClick={onClose}
            className="p-1 h-6 w-6 text-gray-400 hover:text-white"
          >
            <X className="h-3 w-3" />
          </Button>
        </div>
      </div>
      
      {/* Content area */}
      <div className="flex-1 overflow-y-auto p-3 scrollbar-thin">
        <h2 className="text-xl font-semibold mb-2 text-[var(--electric-blue)] glowing-text">
          {currentNote.title}
        </h2>
        
        <div className="flex flex-wrap gap-1 mb-3">
          {currentNote.tags.map(tag => {
            const color = getTagColor(tag);
            return (
              <Badge
                key={tag}
                variant="secondary"
                className="tag-chip text-xs px-1 py-0.5"
                style={{
                  backgroundColor: `${color}20`,
                  color: color,
                  borderColor: `${color}50`,
                  border: '1px solid',
                  fontSize: '0.625rem'
                }}
              >
                {tag}
              </Badge>
            );
          })}
        </div>

        {/* Display image directly if this is an image note */}
        {currentNote.type === 'image' && currentNote.imageData ? (
          <div className="mb-4 flex justify-center">
            <img 
              src={`data:${currentNote.mimeType};base64,${currentNote.imageData}`}
              alt={currentNote.title}
              className="max-w-full max-h-[70vh] rounded-lg shadow-lg"
            />
          </div>
        ) : (
          <NoteEditor
            content={editedContent}
            onSave={(newContent) => {
              setEditedContent(newContent);
              updateNoteMutation.mutate({ id: currentNote.id, content: newContent });
            }}
            isReadOnly={false}
            imageNotes={imageNotes}
            findNoteByTitle={findNoteByTitle}
            onWikiLinkClick={handleWikiLinkClick}
          />
        )}

        <div className="border-t border-gray-700 pt-3 mt-6">
          <p className="text-xs text-gray-400 mb-2">
            <span className="font-mono">Created:</span> {format(currentNote.created, 'PPP')}
          </p>
          <p className="text-xs text-gray-400">
            <span className="font-mono">Connections:</span> {currentNote.connections?.length || 0} notes
          </p>
        </div>
      </div>
    </div>
  );
}
