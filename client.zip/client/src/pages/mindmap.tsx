import { useState, useEffect, useRef, useCallback, useMemo } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { Graph3D } from '@/components/Graph3D';
import { NotePreview } from '@/components/NotePreview';
import { FileExplorer } from '@/components/FileExplorer';
import { Button } from '@/components/ui/button';
import { Slider } from '@/components/ui/slider';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { RefreshCw, Settings, Network, Menu, X, Home, ChevronLeft, ChevronRight } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { apiRequest } from '@/lib/queryClient';
import type { Note } from '@shared/schema';

export default function MindmapPage() {
  const [selectedNote, setSelectedNote] = useState<Note | null>(null);
  
  // Memoize the handleNodeClick function
  const handleNodeClick = useCallback((note: Note) => {
    setSelectedNote(note);
  }, []);
  const [isRegenerating, setIsRegenerating] = useState(false);
  const [sidebarOpen, setSidebarOpen] = useState(true);
  const [homeCameraFn, setHomeCameraFn] = useState<(() => void) | null>(null);
  
  // Persistent window position and size
  const [noteWindowPosition, setNoteWindowPosition] = useState(() => {
    const saved = localStorage.getItem('noteWindowPosition');
    return saved ? JSON.parse(saved) : { x: 100, y: 100 };
  });
  
  const [noteWindowSize, setNoteWindowSize] = useState(() => {
    const saved = localStorage.getItem('noteWindowSize');
    return saved ? JSON.parse(saved) : { width: 500, height: 600 };
  });
  
  // Save position and size to localStorage whenever they change
  useEffect(() => {
    localStorage.setItem('noteWindowPosition', JSON.stringify(noteWindowPosition));
  }, [noteWindowPosition]);
  
  useEffect(() => {
    localStorage.setItem('noteWindowSize', JSON.stringify(noteWindowSize));
  }, [noteWindowSize]);
  
  // Debug logging
  useEffect(() => {
    console.log('homeCameraFn state changed:', homeCameraFn);
  }, [homeCameraFn]);
  
  // Create a wrapper function to debug
  const handleHomeCameraRef = useCallback((fn: () => void) => {
    console.log('handleHomeCameraRef called with:', fn);
    setHomeCameraFn(() => fn);
  }, []);

  // Node size state for settings
  const [nodeSize, setNodeSize] = useState(1);
  const [particleSize, setParticleSize] = useState(1);
  const [nodeDistance, setNodeDistance] = useState(15); // Default distance between nodes
  const labelThreshold = 200; // Fixed threshold value
  const [showSettings, setShowSettings] = useState(false);
  const { toast } = useToast();
  const queryClient = useQueryClient();
  const { data: notes = [], isLoading, error } = useQuery<Note[]>({
    queryKey: ['/api/notes'],
  });

  const regenerateMutation = useMutation({
    mutationFn: async () => {
      const response = await apiRequest('POST', '/api/graph/regenerate');
      return response.json();
    },
    onSuccess: (newNotes) => {
      queryClient.setQueryData(['/api/notes'], newNotes);
      setSelectedNote(null);
      toast({
        title: "Graph Regenerated",
        description: "New knowledge graph generated successfully!",
      });
    },
    onError: () => {
      toast({
        title: "Error",
        description: "Failed to regenerate graph. Please try again.",
        variant: "destructive",
      });
    },
  });

  const handleRegenerate = async () => {
    setIsRegenerating(true);
    await regenerateMutation.mutateAsync();
    setTimeout(() => setIsRegenerating(false), 1500);
  };

  const categoryColors = {
    philosophy: '#FF6B6B',
    science: '#4ECDC4',
    history: '#45B7D1',
    art: '#96CEB4',
    literature: '#FFEEAD',
    psychology: '#D4A5A5',
    technology: '#9B59B6',
    mathematics: '#3498DB',
    biology: '#2ECC71',
    physics: '#E74C3C',
    business: '#FF6B6B'
  };

  const categories = Object.entries(categoryColors).map(([name, color]) => ({
    name: name.charAt(0).toUpperCase() + name.slice(1),
    color
  }));

  const connectionCount = notes.reduce((total, note) => total + (note.connections?.length || 0), 0);

  if (error) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-2xl font-semibold mb-4">Error Loading Graph</h2>
          <p className="text-gray-400 mb-4">Failed to load the knowledge graph data.</p>
          <Button onClick={() => window.location.reload()}>
            <RefreshCw className="w-4 h-4 mr-2" />
            Retry
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="relative w-full h-screen overflow-hidden bg-gradient-to-br from-gray-900 via-black to-gray-900 flex">
      {/* Particle Background */}
      <div className="particle-bg" />
      
      {/* Sidebar */}
      <div className={`relative z-10 transition-all duration-300 ${sidebarOpen ? 'w-80' : 'w-0'}`}>
        {sidebarOpen && (
          <FileExplorer
            onNoteSelect={setSelectedNote}
            selectedNote={selectedNote}
          />
        )}
      </div>

      {/* Sidebar Toggle Button - On Divider */}
      <div className="relative z-20">
        <Button
          onClick={() => setSidebarOpen(!sidebarOpen)}
          className="absolute top-1/2 -translate-y-1/2 -left-3 w-6 h-12 bg-gray-800/90 hover:bg-gray-700/90 text-gray-300 border border-gray-600/50 backdrop-blur-sm rounded-r-lg transition-all duration-200"
          size="sm"
        >
          {sidebarOpen ? <ChevronLeft className="w-3 h-3" /> : <ChevronRight className="w-3 h-3" />}
        </Button>
      </div>

      {/* Main Content */}
      <div className="flex-1 relative">
        {/* Loading Overlay */}
        {(isLoading || isRegenerating) && (
          <div className="absolute inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center z-50">
            <div className="text-center">
              <div className="w-8 h-8 border-2 border-[var(--electric-blue)] border-t-transparent rounded-full animate-spin mx-auto mb-4"></div>
              <p className="text-[var(--electric-blue)] glowing-text">
                {isLoading ? 'Loading Knowledge Graph...' : 'Regenerating Graph...'}
              </p>
            </div>
          </div>
        )}

        {/* 3D Graph */}
        {!isLoading && notes.length > 0 && (
          <Graph3D
            notes={notes}
            onNodeClick={handleNodeClick}
            onHomeCameraRef={handleHomeCameraRef}
            nodeSize={nodeSize}
            particleSize={particleSize}
            labelThreshold={labelThreshold}
            nodeDistance={nodeDistance}
          />
        )}



        {/* Stats Panel */}
        <div className={`stats-panel transition-all duration-300 ${sidebarOpen ? 'left-[21rem]' : 'left-4'}`}>
          <h3 className="text-sm font-semibold mb-2 text-[var(--electric-blue)] glowing-text flex items-center gap-2">
            <Network className="w-4 h-4" />
            Knowledge Graph
          </h3>
          <div className="space-y-1 text-xs">
            <div className="flex justify-between">
              <span className="text-gray-300">Total Notes:</span>
              <span className="text-white font-mono">{notes.length}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-300">Connections:</span>
              <span className="text-white font-mono">{connectionCount}</span>
            </div>
            <div className="flex justify-between">
              <span className="text-gray-300">Categories:</span>
              <span className="text-white font-mono">{categories.length}</span>
            </div>
          </div>
        </div>

        {/* Category Legend */}
        <div className="category-legend">
          <h3 className="text-sm font-semibold mb-3 text-[var(--electric-blue)] glowing-text">Categories</h3>
          <div className="space-y-2">
            {categories.map(({ name, color }) => (
              <div key={name} className="flex items-center gap-2">
                <div 
                  className="w-3 h-3 rounded-full glow-effect"
                  style={{ backgroundColor: color }}
                />
                <span className="text-xs text-gray-300">{name}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Note Preview */}
        {selectedNote && (
          <NotePreview
            note={selectedNote}
            onClose={() => setSelectedNote(null)}
            onNoteSelect={setSelectedNote}
            initialPosition={noteWindowPosition}
            initialSize={noteWindowSize}
            onPositionChange={setNoteWindowPosition}
            onSizeChange={setNoteWindowSize}
          />
        )}



        {/* Control Panel - Bottom Center of Main Panel */}
        <div className="absolute bottom-6 left-1/2 transform -translate-x-1/2 z-20 flex gap-3 bg-gray-900/80 backdrop-blur-sm border border-gray-700/50 rounded-full px-4 py-2">
          <Button
            onClick={() => {
              console.log('Home button clicked, homeCameraFn:', homeCameraFn);
              console.log('Button disabled state:', !homeCameraFn);
              homeCameraFn && homeCameraFn();
            }}
            disabled={!homeCameraFn}
            size="sm"
            className={`${homeCameraFn 
              ? 'bg-green-600/20 hover:bg-green-600/30 text-green-400 border border-green-600/50' 
              : 'bg-gray-600/20 text-gray-500 border border-gray-600/50 cursor-not-allowed'
            } backdrop-blur-sm transition-all duration-200 w-10 h-10 p-0 rounded-full`}
          >
            <Home className="w-4 h-4" />
          </Button>
          
          <Button
            onClick={handleRegenerate}
            disabled={regenerateMutation.isPending}
            size="sm"
            className="bg-[var(--electric-blue)]/20 hover:bg-[var(--electric-blue)]/30 text-[var(--electric-blue)] border border-[var(--electric-blue)]/50 backdrop-blur-sm transition-all duration-200 w-10 h-10 p-0 rounded-full"
          >
            <RefreshCw className={`w-4 h-4 ${regenerateMutation.isPending ? 'animate-spin' : ''}`} />
          </Button>
          
          <Popover>
            <PopoverTrigger asChild>
              <Button
                variant="outline"
                size="sm"
                className="bg-gray-800/50 hover:bg-gray-700/50 text-gray-300 border-gray-600/50 backdrop-blur-sm w-10 h-10 p-0 rounded-full"
              >
                <Settings className="w-4 h-4" />
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-64 bg-gray-900/95 border-gray-700/50 backdrop-blur-sm">
              <div className="space-y-4">
                <div className="space-y-3">
                  <div className="space-y-2">
                    <label className="text-sm text-gray-300">Node size</label>
                    <Slider
                      value={[nodeSize]}
                      onValueChange={(value) => setNodeSize(value[0])}
                      max={3}
                      min={0.5}
                      step={0.1}
                      className="w-full thin-slider"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <label className="text-sm text-gray-300">Particle size</label>
                    <Slider
                      value={[particleSize]}
                      onValueChange={(value) => setParticleSize(value[0])}
                      max={3}
                      min={0.1}
                      step={0.1}
                      className="w-full thin-slider"
                    />
                  </div>
                  
                  <div className="space-y-2">
                    <label className="text-sm text-gray-300">Node distance</label>
                    <Slider
                      value={[nodeDistance]}
                      onValueChange={(value) => setNodeDistance(value[0])}
                      max={30}
                      min={5}
                      step={1}
                      className="w-full thin-slider"
                    />
                    <span className="text-xs text-gray-400">Controls spacing between connected nodes</span>
                  </div>
                </div>
              </div>
            </PopoverContent>
          </Popover>
        </div>
      </div>
    </div>
  );
}
