import { faker } from '@faker-js/faker';
import type { Note } from '@shared/schema';

const TAGS = [
  'business', 'psychology', 'mindset', 'wealth', 'marketing',
  'leadership', 'productivity', 'personal-development', 'biology', 'strategy',
  'philosophy', 'science', 'technology', 'art', 'creativity'
];

const CATEGORIES = [
  'business', 'psychology', 'philosophy', 'biology', 'science',
  'technology', 'art', 'history', 'literature', 'mathematics'
];

export function generateRandomNotes(count: number): Omit<Note, 'id' | 'created'>[] {
  const notes: Omit<Note, 'id' | 'created'>[] = [];

  for (let i = 0; i < count; i++) {
    const category = faker.helpers.arrayElement(CATEGORIES);
    const relevantTags = TAGS.filter(tag => 
      tag === category || 
      (category === 'business' && ['marketing', 'leadership', 'wealth', 'strategy'].includes(tag)) ||
      (category === 'psychology' && ['mindset', 'productivity', 'personal-development'].includes(tag)) ||
      (category === 'art' && ['creativity'].includes(tag))
    );

    const note = {
      title: faker.lorem.sentence(3),
      content: faker.lorem.paragraphs(2),
      tags: faker.helpers.arrayElements(relevantTags.length > 0 ? relevantTags : TAGS, { min: 1, max: 3 }),
      category,
      connections: [] as number[]
    };

    notes.push(note);
  }

  return notes;
}

export function generateConnections(notes: Note[]): void {
  notes.forEach(note => {
    const connectionCount = faker.number.int({ min: 1, max: 5 });
    const possibleConnections = notes.filter(n => n.id !== note.id);
    const connections: number[] = [];

    for (let i = 0; i < connectionCount && i < possibleConnections.length; i++) {
      const randomNote = faker.helpers.arrayElement(possibleConnections);
      if (!connections.includes(randomNote.id)) {
        connections.push(randomNote.id);
      }
    }

    note.connections = connections;
  });
}
