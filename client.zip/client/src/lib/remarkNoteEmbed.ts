import { visit } from 'unist-util-visit';
import type { Node } from 'unist';
import type { Text } from 'mdast';

interface NoteEmbedNode extends Node {
  type: 'html';
  value: string;
}

export function remarkNoteEmbed() {
  return (tree: Node) => {
    visit(tree, 'text', (node: Text, index: number, parent: any) => {
      if (!parent || index === null) return;

      const noteEmbedRegex = /!\[\[([^\]]+)\]\]/g;
      const matches = Array.from(node.value.matchAll(noteEmbedRegex));

      if (matches.length === 0) return;

      console.log('remarkNoteEmbed: Found matches:', matches);

      const newNodes: (Text | NoteEmbedNode)[] = [];
      let lastIndex = 0;

      matches.forEach((match) => {
        const [fullMatch, noteTitle] = match;
        const startIndex = match.index!;

        // Add text before the match
        if (startIndex > lastIndex) {
          newNodes.push({
            type: 'text',
            value: node.value.slice(lastIndex, startIndex),
          });
        }

        console.log('remarkNoteEmbed: Creating embed for:', noteTitle);

        // Create a paragraph node with special marker
        const noteEmbed: any = {
          type: 'paragraph',
          data: {
            hName: 'div',
            hProperties: {
              className: 'note-embed-container',
              'data-note-title': noteTitle.trim()
            }
          },
          children: [{
            type: 'text',
            value: `NOTE_EMBED:${noteTitle.trim()}`
          }]
        };
        newNodes.push(noteEmbed);

        lastIndex = startIndex + fullMatch.length;
      });

      // Add remaining text
      if (lastIndex < node.value.length) {
        newNodes.push({
          type: 'text',
          value: node.value.slice(lastIndex),
        });
      }

      // Replace the current node with new nodes
      parent.children.splice(index, 1, ...newNodes);
    });
  };
}