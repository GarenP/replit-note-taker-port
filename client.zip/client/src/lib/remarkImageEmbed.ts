import { visit } from 'unist-util-visit';
import type { Node } from 'unist';
import type { Text } from 'mdast';

interface ImageEmbedNode extends Node {
  type: 'imageEmbed';
  data: {
    noteTitle: string;
  };
  children: Text[];
}

export function remarkImageEmbed() {
  return (tree: Node) => {
    visit(tree, 'text', (node: Text, index: number, parent: any) => {
      if (!parent || index === null) return;

      const imageEmbedRegex = /!\[\[([^\]]+)\]\]/g;
      const matches = Array.from(node.value.matchAll(imageEmbedRegex));

      if (matches.length === 0) return;

      const newNodes: (Text | ImageEmbedNode)[] = [];
      let lastIndex = 0;

      matches.forEach((match) => {
        const [fullMatch, noteTitle] = match;
        const startIndex = match.index!;

        // Add text before the match
        if (startIndex > lastIndex) {
          newNodes.push({
            type: 'text',
            value: node.value.slice(lastIndex, startIndex),
          });
        }

        // Only process files that look like direct image references with extensions
        // but haven't been processed by noteEmbed (this runs after noteEmbed now)
        const trimmedTitle = noteTitle.trim();
        const imageExtensions = ['.png', '.jpg', '.jpeg', '.gif', '.webp', '.svg'];
        const hasImageExtension = imageExtensions.some(ext => trimmedTitle.toLowerCase().endsWith(ext));

        if (hasImageExtension) {
          // Add the image embed node for direct image references
          const imageEmbed: ImageEmbedNode = {
            type: 'imageEmbed',
            data: {
              noteTitle: trimmedTitle,
            },
            children: [{
              type: 'text',
              value: noteTitle,
            }],
          };
          newNodes.push(imageEmbed);
        } else {
          // Not an image file, keep as regular text
          newNodes.push({
            type: 'text',
            value: fullMatch,
          });
        }

        lastIndex = startIndex + fullMatch.length;
      });

      // Add remaining text
      if (lastIndex < node.value.length) {
        newNodes.push({
          type: 'text',
          value: node.value.slice(lastIndex),
        });
      }

      // Replace the current node with new nodes
      parent.children.splice(index, 1, ...newNodes);
    });
  };
}