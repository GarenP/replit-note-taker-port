import { visit } from 'unist-util-visit';
import type { Node } from 'unist';
import type { Text, Link } from 'mdast';

interface WikiLinkNode extends Node {
  type: 'wikiLink';
  data: {
    alias?: string;
    permalink: string;
  };
  children: Text[];
}

// Custom remark plugin to parse [[]] wiki links
export function remarkWikiLink() {
  return (tree: Node) => {
    visit(tree, 'text', (node: Text, index: number, parent: any) => {
      if (!node.value || typeof node.value !== 'string') return;

      const wikiLinkRegex = /\[\[([^\]]+)\]\]/g;
      const parts = [];
      let lastIndex = 0;
      let match;

      // Reset the regex state
      wikiLinkRegex.lastIndex = 0;
      
      while ((match = wikiLinkRegex.exec(node.value)) !== null) {
        // Add text before the link
        if (match.index > lastIndex) {
          parts.push({
            type: 'text',
            value: node.value.slice(lastIndex, match.index)
          });
        }

        // Parse the wiki link content
        const linkContent = match[1];
        const [title, alias] = linkContent.includes('|') 
          ? linkContent.split('|', 2).map(s => s.trim())
          : [linkContent.trim(), linkContent.trim()];

        // Create a standard link node instead of custom wikiLink
        const wikiLink: Link = {
          type: 'link',
          url: `#wiki:${title}`,
          title: `Wiki link to ${title}`,
          data: {
            isWikiLink: true,
            permalink: title,
            alias
          },
          children: [{
            type: 'text',
            value: alias  // Remove the [[ ]] brackets from display
          }]
        };

        parts.push(wikiLink);
        lastIndex = match.index + match[0].length;
      }

      // Add remaining text
      if (lastIndex < node.value.length) {
        parts.push({
          type: 'text',
          value: node.value.slice(lastIndex)
        });
      }

      // Replace the text node with the parsed parts if we found any wiki links
      if (parts.length > 0) {
        parent.children.splice(index, 1, ...parts);
      }
    });
  };
}