import type { InsertNote } from '@shared/schema';

export const entrepreneurNotes: InsertNote[] = [
  {
    title: "Rich Dad's Cash Flow Quadrant",
    content: "The key difference between an employee and a business owner is that one works for money, while the other builds systems that generate money. Understanding this fundamental shift in mindset is crucial for anyone looking to achieve financial independence.",
    tags: ['business', 'wealth', 'mindset'],
    category: 'business',
    connections: []
  },
  {
    title: "Influence: The Psychology of Persuasion",
    content: "The principle of social proof states that people tend to look at others' actions to determine their own behavior, especially in uncertain situations. This powerful psychological trigger can be leveraged in marketing and leadership.\n\nThis connects to [[The Choice Factory]] and behavioral science principles. It's also fundamental to [[High Performance Habits]] and [[Dopamine and Decision Making]].",
    tags: ['psychology', 'marketing', 'influence'],
    category: 'psychology',
    connections: []
  },
  {
    title: "100M Offers by Alex Hormozi",
    content: "The grand slam offer framework: The better your offer, the less you need to be good at everything else in marketing and sales. Focus on creating irresistible value propositions that customers can't refuse.\n\nThis concept relates to [[Influence: The Psychology of Persuasion]] and the importance of [[Strategic Business Thinking]] in creating competitive advantages.",
    tags: ['marketing', 'business', 'sales'],
    category: 'business',
    connections: []
  },
  {
    title: "Steal Like an Artist",
    content: "Nothing is completely original. All creative work builds on what came before. Embrace influence, don't run away from it. The key is to transform your influences into something uniquely yours.",
    tags: ['creativity', 'art', 'mindset'],
    category: 'art',
    connections: []
  },
  {
    title: "Man's Search for Meaning",
    content: "Those who have a 'why' to live can bear with almost any 'how'. Success, like happiness, cannot be pursued; it must ensue from meaningful work and relationships.",
    tags: ['psychology', 'philosophy', 'meaning'],
    category: 'philosophy',
    connections: []
  },
  {
    title: "Finding My Virginity",
    content: "Business opportunities are like buses, there's always another one coming. The key is to recognize them when they appear and have the courage to act on them.",
    tags: ['business', 'entrepreneurship', 'opportunities'],
    category: 'business',
    connections: []
  },
  {
    title: "The Choice Factory",
    content: "Understanding behavioral science is crucial for effective marketing. People make decisions based on cognitive biases and mental shortcuts rather than rational analysis.",
    tags: ['psychology', 'marketing', 'behavior'],
    category: 'psychology',
    connections: []
  },
  {
    title: "Dopamine and Decision Making",
    content: "Neuroscience research shows that dopamine not only rewards us for good choices but helps with decision making and risk assessment. Understanding this can improve both personal and business decisions.",
    tags: ['biology', 'psychology', 'neuroscience'],
    category: 'biology',
    connections: []
  },
  {
    title: "High Performance Habits",
    content: "The most successful entrepreneurs maintain strict routines and habits that optimize their energy and focus throughout the day. Consistency in small actions leads to extraordinary results.",
    tags: ['productivity', 'habits', 'performance'],
    category: 'psychology',
    connections: []
  },
  {
    title: "Strategic Business Thinking",
    content: "Effective strategy isn't about being better at the same things; it's about choosing to do different things or doing things differently. Competitive advantage comes from uniqueness, not just efficiency.",
    tags: ['strategy', 'business', 'competitive-advantage'],
    category: 'business',
    connections: []
  }
];
