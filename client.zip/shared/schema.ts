import { pgTable, text, serial, integer, timestamp, jsonb } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

// Users table for OAuth preparation
export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  email: text("email").notNull().unique(),
  username: text("username").notNull().unique(),
  name: text("name"),
  avatarUrl: text("avatar_url"),
  provider: text("provider"), // 'google', 'github', etc.
  providerId: text("provider_id"), // OAuth provider's user ID
  created: timestamp("created").defaultNow().notNull(),
  updated: timestamp("updated").defaultNow().notNull(),
});

export const folders = pgTable("folders", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  parentId: integer("parent_id"),
  userId: integer("user_id"), // Will be required when OAuth is implemented
  created: timestamp("created").defaultNow().notNull(),
});

export const notes = pgTable("notes", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  content: text("content").notNull(), // Store as markdown
  tags: jsonb("tags").$type<string[]>().notNull().default([]),
  category: text("category").notNull(),
  folderId: integer("folder_id"),
  userId: integer("user_id"), // Will be required when OAuth is implemented
  connections: jsonb("connections").$type<number[]>().notNull().default([]),
  created: timestamp("created").defaultNow().notNull(),
  updated: timestamp("updated").defaultNow().notNull(),
  type: text("type").notNull().default("text"), // 'text' or 'image'
  imageData: text("image_data"), // Base64 encoded image data for image notes
  mimeType: text("mime_type"), // MIME type for the image
});

export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  created: true,
  updated: true,
});

export const insertFolderSchema = createInsertSchema(folders).omit({
  id: true,
  created: true,
});

export const insertNoteSchema = createInsertSchema(notes).omit({
  id: true,
  created: true,
  updated: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type InsertFolder = z.infer<typeof insertFolderSchema>;
export type Folder = typeof folders.$inferSelect;
export type InsertNote = z.infer<typeof insertNoteSchema>;
export type Note = typeof notes.$inferSelect;
