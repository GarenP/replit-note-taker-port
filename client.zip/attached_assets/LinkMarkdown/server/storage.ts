import { users, notes, type User, type InsertUser, type Note, type InsertNote, type UpdateNote } from "@shared/schema";

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  
  getNotes(userId: number): Promise<Note[]>;
  getNote(id: number, userId: number): Promise<Note | undefined>;
  createNote(note: InsertNote): Promise<Note>;
  updateNote(id: number, userId: number, updates: UpdateNote): Promise<Note | undefined>;
  deleteNote(id: number, userId: number): Promise<boolean>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private notes: Map<number, Note>;
  private currentUserId: number;
  private currentNoteId: number;

  constructor() {
    this.users = new Map();
    this.notes = new Map();
    this.currentUserId = 1;
    this.currentNoteId = 1;
    
    // Create a default user for demo purposes
    this.users.set(1, {
      id: 1,
      username: "demo",
      password: "demo"
    });
    this.currentUserId = 2;
    
    // Create demo notes
    this.createDemoNotes();
  }

  private createDemoNotes() {
    const now = new Date();
    
    // Welcome note
    this.notes.set(1, {
      id: 1,
      title: "Welcome to Your Note-Taking App",
      content: `<h1>Welcome to Your Note-Taking App</h1>
        <p>This is an Obsidian-inspired note-taking experience with 6 different editor variants to explore.</p>
        <h2>Key Features</h2>
        <ul>
          <li><strong>Seamless Editing</strong> - Click anywhere to start editing, markdown formatting appears as you type</li>
          <li><strong>Multiple Layouts</strong> - Switch between 6 different editor experiences</li>
          <li><strong>Dark Theme</strong> - Minimalist design focused on your content</li>
          <li><strong>Real-time Save</strong> - Your changes are saved automatically</li>
        </ul>
        <blockquote>"The best way to find out if you can trust somebody is to trust them." - Ernest Hemingway</blockquote>
        <p>Try switching between the different variants using the buttons in the top right corner!</p>`,
      userId: 1,
      createdAt: new Date(now.getTime() - 1000 * 60 * 60 * 2), // 2 hours ago
      updatedAt: new Date(now.getTime() - 1000 * 60 * 60 * 2),
      isDeleted: false,
    });

    // Daily thoughts
    this.notes.set(2, {
      id: 2,
      title: "Daily Thoughts & Ideas",
      content: `<h1>Daily Thoughts & Ideas</h1>
        <h2>Morning Reflection</h2>
        <p>Started the day with a clear mind. The new note-taking interface feels intuitive and responsive.</p>
        <h2>Project Ideas</h2>
        <ul>
          <li>Implement bidirectional linking between notes</li>
          <li>Add tag system for better organization</li>
          <li>Create template system for common note types</li>
          <li>Add search functionality across all notes</li>
        </ul>
        <h2>Technical Notes</h2>
        <p>The TipTap editor provides excellent extensibility for custom formatting. BlockNote offers a more structured approach similar to Notion.</p>
        <pre><code>// Example of custom formatting
const customEditor = useEditor({
  extensions: [StarterKit, CustomExtension],
  content: initialContent
});</code></pre>`,
      userId: 1,
      createdAt: new Date(now.getTime() - 1000 * 60 * 60 * 4), // 4 hours ago
      updatedAt: new Date(now.getTime() - 1000 * 60 * 30), // 30 minutes ago
      isDeleted: false,
    });

    // Quick note
    this.notes.set(3, {
      id: 3,
      title: "Quick Note",
      content: `<h1>Quick Note</h1>
        <p>Sometimes the best ideas come in quick bursts. This minimal interface makes it easy to capture thoughts without distraction.</p>
        <p><strong>Remember:</strong> Focus on the content, not the interface. The tools should fade away, leaving only your thoughts.</p>`,
      userId: 1,
      createdAt: new Date(now.getTime() - 1000 * 60 * 60 * 1), // 1 hour ago
      updatedAt: new Date(now.getTime() - 1000 * 60 * 60 * 1),
      isDeleted: false,
    });

    // Meeting notes
    this.notes.set(4, {
      id: 4,
      title: "Meeting Notes - Design Review",
      content: `<h1>Meeting Notes - Design Review</h1>
        <h2>Attendees</h2>
        <ul>
          <li>Design Team</li>
          <li>Development Team</li>
          <li>Product Manager</li>
        </ul>
        <h2>Key Discussion Points</h2>
        <ol>
          <li><strong>User Experience</strong> - Focus on intuitive navigation</li>
          <li><strong>Visual Design</strong> - Maintain clean, minimal aesthetic</li>
          <li><strong>Performance</strong> - Ensure smooth animations and responsiveness</li>
        </ol>
        <h2>Action Items</h2>
        <ul>
          <li>Implement user testing for all editor variants</li>
          <li>Refine color scheme based on accessibility guidelines</li>
          <li>Optimize loading times for large notes</li>
        </ul>`,
      userId: 1,
      createdAt: new Date(now.getTime() - 1000 * 60 * 60 * 6), // 6 hours ago
      updatedAt: new Date(now.getTime() - 1000 * 60 * 60 * 6),
      isDeleted: false,
    });

    this.currentNoteId = 5;
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async getNotes(userId: number): Promise<Note[]> {
    return Array.from(this.notes.values())
      .filter((note) => note.userId === userId && !note.isDeleted)
      .sort((a, b) => new Date(b.updatedAt || b.createdAt!).getTime() - new Date(a.updatedAt || a.createdAt!).getTime());
  }

  async getNote(id: number, userId: number): Promise<Note | undefined> {
    const note = this.notes.get(id);
    if (note && note.userId === userId && !note.isDeleted) {
      return note;
    }
    return undefined;
  }

  async createNote(insertNote: InsertNote): Promise<Note> {
    const id = this.currentNoteId++;
    const now = new Date();
    const note: Note = {
      id,
      title: insertNote.title,
      content: insertNote.content,
      userId: insertNote.userId,
      createdAt: now,
      updatedAt: now,
      isDeleted: false,
    };
    this.notes.set(id, note);
    return note;
  }

  async updateNote(id: number, userId: number, updates: UpdateNote): Promise<Note | undefined> {
    const note = this.notes.get(id);
    if (note && note.userId === userId && !note.isDeleted) {
      const updatedNote = {
        ...note,
        ...updates,
        updatedAt: new Date(),
      };
      this.notes.set(id, updatedNote);
      return updatedNote;
    }
    return undefined;
  }

  async deleteNote(id: number, userId: number): Promise<boolean> {
    const note = this.notes.get(id);
    if (note && note.userId === userId && !note.isDeleted) {
      this.notes.set(id, { ...note, isDeleted: true });
      return true;
    }
    return false;
  }
}

export const storage = new MemStorage();
