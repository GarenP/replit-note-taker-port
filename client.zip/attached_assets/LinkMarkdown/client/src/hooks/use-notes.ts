import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Note, InsertNote, UpdateNote } from "@shared/schema";
import { apiRequest } from "@/lib/queryClient";

export function useNotes() {
  const queryClient = useQueryClient();

  const { data: notes = [], isLoading, error } = useQuery<Note[]>({
    queryKey: ["/api/notes"],
  });

  const createNoteMutation = useMutation({
    mutationFn: async (note: InsertNote) => {
      const response = await apiRequest("POST", "/api/notes", note);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/notes"] });
    },
  });

  const updateNoteMutation = useMutation({
    mutationFn: async ({ id, updates }: { id: number; updates: UpdateNote }) => {
      const response = await apiRequest("PUT", `/api/notes/${id}`, updates);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/notes"] });
    },
  });

  const deleteNoteMutation = useMutation({
    mutationFn: async (id: number) => {
      const response = await apiRequest("DELETE", `/api/notes/${id}`);
      return response.json();
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/notes"] });
    },
  });

  return {
    notes,
    isLoading,
    error,
    createNote: createNoteMutation.mutateAsync,
    updateNote: (id: number, updates: UpdateNote) => 
      updateNoteMutation.mutateAsync({ id, updates }),
    deleteNote: deleteNoteMutation.mutateAsync,
    isCreating: createNoteMutation.isPending,
    isUpdating: updateNoteMutation.isPending,
    isDeleting: deleteNoteMutation.isPending,
  };
}
