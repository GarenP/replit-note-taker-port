import { MinimalEditor } from "@/components/variants/minimal-editor";

export default function Home() {
  return (
    <div className="min-h-screen bg-background text-foreground">
      <MinimalEditor />
    </div>
  );
}
