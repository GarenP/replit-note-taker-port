import { useState } from "react";
import { TiptapEditor } from "@/components/editors/tiptap-editor";
import { useNotes } from "@/hooks/use-notes";
import { Button } from "@/components/ui/button";
import { FileText, Plus } from "lucide-react";
import { Note } from "@shared/schema";

export function MinimalEditor() {
  const { notes, createNote, updateNote } = useNotes();
  const [selectedNote, setSelectedNote] = useState<Note | null>(notes[0] || null);

  const handleCreateNote = async () => {
    const newNote = await createNote({
      title: "New Note",
      content: `<h1>New Note</h1><p>Start writing your thoughts here...</p>`,
      userId: 1,
    });
    setSelectedNote(newNote);
  };

  const handleSave = async (content: string) => {
    if (selectedNote) {
      await updateNote(selectedNote.id, { content });
    }
  };

  if (!selectedNote) {
    return (
      <div className="flex items-center justify-center h-screen">
        <div className="text-center">
          <FileText className="w-16 h-16 text-muted-foreground mx-auto mb-4" />
          <h2 className="text-2xl font-light mb-4">Minimal Notes</h2>
          <p className="text-muted-foreground mb-6">
            Distraction-free writing. Click to begin.
          </p>
          <Button onClick={handleCreateNote} variant="outline">
            <Plus className="w-4 h-4 mr-2" />
            Start Writing
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-3xl mx-auto p-8">
      <div className="mb-6 text-center">
        <div className="inline-flex items-center space-x-2 text-muted-foreground mb-4">
          <FileText className="w-4 h-4" />
          <span className="text-sm">{selectedNote.title}</span>
        </div>
      </div>

      <div className="prose prose-invert max-w-none">
        <TiptapEditor
          note={selectedNote}
          onSave={handleSave}
          placeholder="Start writing..."
        />
      </div>
    </div>
  );
}
