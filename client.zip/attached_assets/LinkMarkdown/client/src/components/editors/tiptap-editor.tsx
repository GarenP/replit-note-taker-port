import { useEffect, useRef } from "react";
import { useEditor, EditorContent } from "@tiptap/react";
import StarterKit from "@tiptap/starter-kit";
import Typography from "@tiptap/extension-typography";
import Placeholder from "@tiptap/extension-placeholder";
import { ObsidianMarkdownV2 } from "@/lib/obsidian-markdown-v2";
import { DisableInputRules } from "@/lib/disable-input-rules";
import { Note } from "@shared/schema";
import { Button } from "@/components/ui/button";
import { 
  Bold, 
  Italic, 
  Strikethrough, 
  Code,
  List,
  ListOrdered,
  Quote,
  Heading1,
  Heading2,
  Heading3,
  Undo,
  Redo,
  Code2,
  Minus
} from "lucide-react";

interface TiptapEditorProps {
  note?: Note;
  onSave?: (content: string) => void;
  placeholder?: string;
  editable?: boolean;
}



export function TiptapEditor({ note, onSave, placeholder = "Start typing...", editable = true }: TiptapEditorProps) {
  const saveTimeout = useRef<NodeJS.Timeout>();

  const editor = useEditor({
    extensions: [
      StarterKit.configure({
        // Disable ALL input rules globally
        dropcursor: false,
        gapcursor: false,
        history: {
          depth: 100,
        },
        // Configure individual extensions
        bold: {
          HTMLAttributes: {
            class: 'font-bold',
          },
        },
        italic: {
          HTMLAttributes: {
            class: 'italic',
          },
        },
        strike: {
          HTMLAttributes: {
            class: 'line-through',
          },
        },
        code: {
          HTMLAttributes: {
            class: 'bg-gray-700 px-2 py-1 rounded font-mono text-sm',
          },
        },
        codeBlock: {
          HTMLAttributes: {
            class: 'bg-gray-800 p-4 rounded-lg font-mono text-sm overflow-x-auto',
          },
        },
        bulletList: {
          HTMLAttributes: {
            class: 'list-disc list-inside space-y-2',
          },
        },
        orderedList: {
          HTMLAttributes: {
            class: 'list-decimal list-inside space-y-2',
          },
        },
        listItem: {
          HTMLAttributes: {
            class: 'ml-4',
          },
        },
        blockquote: {
          HTMLAttributes: {
            class: 'border-l-4 border-gray-600 pl-4 italic',
          },
        },
        heading: {
          levels: [1, 2, 3],
          HTMLAttributes: {
            class: 'font-bold',
          },
        },
        horizontalRule: {
          HTMLAttributes: {
            class: 'border-t border-gray-600 my-4',
          },
        },
      }),
      Typography.configure({
        // Disable typography input rules
        openDoubleQuote: false,
        closeDoubleQuote: false,
        openSingleQuote: false,
        closeSingleQuote: false,
        emDash: false,
        ellipsis: false,
      }),
      Placeholder.configure({
        placeholder,
      }),
      DisableInputRules,
      ObsidianMarkdownV2,
    ],
    content: note?.content || "",
    editable,
    editorProps: {
      attributes: {
        class: 'prose prose-invert max-w-none focus:outline-none',
      },
      transformPasted: false,
    },
    onUpdate: ({ editor }) => {
      const content = editor.getHTML();
      
      if (onSave) {
        // Debounce save
        clearTimeout(saveTimeout.current);
        saveTimeout.current = setTimeout(() => {
          onSave(content);
        }, 500);
      }
    },
  });

  useEffect(() => {
    if (note?.content && editor) {
      editor.commands.setContent(note.content);
    }
  }, [note?.content, editor]);

  if (!editor) {
    return null;
  }

  return (
    <div className="tiptap-editor">
      {/* Toolbar */}
      <div className="sticky top-0 z-10 bg-background border-b border-gray-800 p-2 mb-4">
        <div className="flex flex-wrap gap-1">
          {/* Text formatting */}
          <Button
            size="sm"
            variant={editor.isActive('bold') ? 'secondary' : 'ghost'}
            onClick={() => editor.chain().focus().toggleBold().run()}
            disabled={!editor.can().chain().focus().toggleBold().run()}
            className="h-8 w-8 p-0"
          >
            <Bold className="h-4 w-4" />
          </Button>
          <Button
            size="sm"
            variant={editor.isActive('italic') ? 'secondary' : 'ghost'}
            onClick={() => editor.chain().focus().toggleItalic().run()}
            disabled={!editor.can().chain().focus().toggleItalic().run()}
            className="h-8 w-8 p-0"
          >
            <Italic className="h-4 w-4" />
          </Button>
          <Button
            size="sm"
            variant={editor.isActive('strike') ? 'secondary' : 'ghost'}
            onClick={() => editor.chain().focus().toggleStrike().run()}
            disabled={!editor.can().chain().focus().toggleStrike().run()}
            className="h-8 w-8 p-0"
          >
            <Strikethrough className="h-4 w-4" />
          </Button>
          <Button
            size="sm"
            variant={editor.isActive('code') ? 'secondary' : 'ghost'}
            onClick={() => editor.chain().focus().toggleCode().run()}
            disabled={!editor.can().chain().focus().toggleCode().run()}
            className="h-8 w-8 p-0"
          >
            <Code className="h-4 w-4" />
          </Button>
          
          <div className="w-px h-8 bg-gray-700 mx-1" />
          
          {/* Headings */}
          <Button
            size="sm"
            variant={editor.isActive('heading', { level: 1 }) ? 'secondary' : 'ghost'}
            onClick={() => editor.chain().focus().toggleHeading({ level: 1 }).run()}
            className="h-8 w-8 p-0"
          >
            <Heading1 className="h-4 w-4" />
          </Button>
          <Button
            size="sm"
            variant={editor.isActive('heading', { level: 2 }) ? 'secondary' : 'ghost'}
            onClick={() => editor.chain().focus().toggleHeading({ level: 2 }).run()}
            className="h-8 w-8 p-0"
          >
            <Heading2 className="h-4 w-4" />
          </Button>
          <Button
            size="sm"
            variant={editor.isActive('heading', { level: 3 }) ? 'secondary' : 'ghost'}
            onClick={() => editor.chain().focus().toggleHeading({ level: 3 }).run()}
            className="h-8 w-8 p-0"
          >
            <Heading3 className="h-4 w-4" />
          </Button>
          
          <div className="w-px h-8 bg-gray-700 mx-1" />
          
          {/* Lists */}
          <Button
            size="sm"
            variant={editor.isActive('bulletList') ? 'secondary' : 'ghost'}
            onClick={() => editor.chain().focus().toggleBulletList().run()}
            className="h-8 w-8 p-0"
          >
            <List className="h-4 w-4" />
          </Button>
          <Button
            size="sm"
            variant={editor.isActive('orderedList') ? 'secondary' : 'ghost'}
            onClick={() => editor.chain().focus().toggleOrderedList().run()}
            className="h-8 w-8 p-0"
          >
            <ListOrdered className="h-4 w-4" />
          </Button>
          <Button
            size="sm"
            variant={editor.isActive('blockquote') ? 'secondary' : 'ghost'}
            onClick={() => editor.chain().focus().toggleBlockquote().run()}
            className="h-8 w-8 p-0"
          >
            <Quote className="h-4 w-4" />
          </Button>
          
          <div className="w-px h-8 bg-gray-700 mx-1" />
          
          {/* Code block and Horizontal rule */}
          <Button
            size="sm"
            variant={editor.isActive('codeBlock') ? 'secondary' : 'ghost'}
            onClick={() => editor.chain().focus().toggleCodeBlock().run()}
            className="h-8 px-3 text-xs"
          >
            Code block
          </Button>
          <Button
            size="sm"
            variant="ghost"
            onClick={() => editor.chain().focus().toggleBlockquote().run()}
            className="h-8 px-3 text-xs"
          >
            Blockquote
          </Button>
          <Button
            size="sm"
            variant="ghost"
            onClick={() => editor.chain().focus().setHorizontalRule().run()}
            className="h-8 px-3 text-xs"
          >
            Horizontal rule
          </Button>
          
          <div className="w-px h-8 bg-gray-700 mx-1" />
          
          {/* History */}
          <Button
            size="sm"
            variant="ghost"
            onClick={() => editor.chain().focus().undo().run()}
            disabled={!editor.can().chain().focus().undo().run()}
            className="h-8 w-8 p-0"
          >
            <Undo className="h-4 w-4" />
          </Button>
          <Button
            size="sm"
            variant="ghost"
            onClick={() => editor.chain().focus().redo().run()}
            disabled={!editor.can().chain().focus().redo().run()}
            className="h-8 w-8 p-0"
          >
            <Redo className="h-4 w-4" />
          </Button>
        </div>
      </div>
      
      {/* Editor */}
      <EditorContent editor={editor} />
    </div>
  );
}
