import { Extension } from '@tiptap/core'
import { Plugin, PluginKey } from '@tiptap/pm/state'
import { Decoration, DecorationSet } from '@tiptap/pm/view'
import { TextSelection } from '@tiptap/pm/state'

export const ObsidianMarkdownV2 = Extension.create({
  name: 'obsidianMarkdownV2',

  addProseMirrorPlugins() {
    console.log('ObsidianMarkdownV2 plugin loading...')
    return [
      new Plugin({
        key: new PluginKey('obsidianMarkdownV2'),
        state: {
          init(_, { doc }) {
            return DecorationSet.empty
          },
          apply(tr, oldState, _, newState) {
            const decorations: Decoration[] = []
            const { selection } = newState
            
            console.log('ObsidianMarkdownV2 apply called', { selection: selection.toJSON() })
            
            // Only process if we have a text selection
            if (selection instanceof TextSelection) {
              const $pos = selection.$from
              const node = $pos.parent
              const startOfLine = $pos.start()
              
              if (node && node.type.name === 'paragraph' && node.textContent) {
                const text = node.textContent
                console.log('Processing text:', text)
                
                // Check for markdown patterns
                const patterns = [
                  {
                    // Headers (only at start of line)
                    regex: /^(#{1,6})\s+(.*)$/,
                    handler: (match: RegExpMatchArray, pos: number) => {
                      const level = match[1].length
                      const syntaxEnd = pos + match[1].length
                      const contentStart = syntaxEnd + 1
                      
                      // Gray syntax
                      decorations.push(
                        Decoration.inline(pos, syntaxEnd, {
                          style: 'color: #64748b;'
                        })
                      )
                      
                      // Style content based on heading level
                      const sizes = ['2.5em', '2em', '1.5em', '1.25em', '1.1em', '1em']
                      decorations.push(
                        Decoration.inline(contentStart, pos + match[0].length, {
                          style: `font-size: ${sizes[level - 1]}; font-weight: bold;`
                        })
                      )
                    }
                  },
                  {
                    // Bold
                    regex: /\*\*([^*]+)\*\*/g,
                    handler: (match: RegExpMatchArray, pos: number) => {
                      const start = pos + match.index!
                      const end = start + match[0].length
                      const contentStart = start + 2
                      const contentEnd = end - 2
                      
                      // Gray syntax
                      decorations.push(
                        Decoration.inline(start, contentStart, { style: 'color: #64748b;' }),
                        Decoration.inline(contentEnd, end, { style: 'color: #64748b;' })
                      )
                      
                      // Bold content
                      decorations.push(
                        Decoration.inline(contentStart, contentEnd, { style: 'font-weight: bold;' })
                      )
                    }
                  },
                  {
                    // Italic
                    regex: /(?<!\*)\*([^*]+)\*(?!\*)/g,
                    handler: (match: RegExpMatchArray, pos: number) => {
                      const start = pos + match.index!
                      const end = start + match[0].length
                      const contentStart = start + 1
                      const contentEnd = end - 1
                      
                      // Gray syntax
                      decorations.push(
                        Decoration.inline(start, contentStart, { style: 'color: #64748b;' }),
                        Decoration.inline(contentEnd, end, { style: 'color: #64748b;' })
                      )
                      
                      // Italic content
                      decorations.push(
                        Decoration.inline(contentStart, contentEnd, { style: 'font-style: italic;' })
                      )
                    }
                  },
                  {
                    // Strikethrough
                    regex: /~~([^~]+)~~/g,
                    handler: (match: RegExpMatchArray, pos: number) => {
                      const start = pos + match.index!
                      const end = start + match[0].length
                      const contentStart = start + 2
                      const contentEnd = end - 2
                      
                      // Gray syntax
                      decorations.push(
                        Decoration.inline(start, contentStart, { style: 'color: #64748b;' }),
                        Decoration.inline(contentEnd, end, { style: 'color: #64748b;' })
                      )
                      
                      // Strikethrough content
                      decorations.push(
                        Decoration.inline(contentStart, contentEnd, { style: 'text-decoration: line-through;' })
                      )
                    }
                  },
                  {
                    // Code
                    regex: /`([^`]+)`/g,
                    handler: (match: RegExpMatchArray, pos: number) => {
                      const start = pos + match.index!
                      const end = start + match[0].length
                      const contentStart = start + 1
                      const contentEnd = end - 1
                      
                      // Gray syntax
                      decorations.push(
                        Decoration.inline(start, contentStart, { style: 'color: #64748b;' }),
                        Decoration.inline(contentEnd, end, { style: 'color: #64748b;' })
                      )
                      
                      // Code content
                      decorations.push(
                        Decoration.inline(contentStart, contentEnd, { 
                          style: 'background-color: #374151; padding: 2px 4px; border-radius: 4px; font-family: monospace; font-size: 0.9em;' 
                        })
                      )
                    }
                  }
                ]
                
                // Apply patterns
                patterns.forEach(pattern => {
                  if (pattern.regex.global) {
                    // For global patterns (bold, italic, etc)
                    let match
                    while ((match = pattern.regex.exec(text)) !== null) {
                      pattern.handler(match, startOfLine + 1)
                    }
                  } else {
                    // For line-start patterns (headers)
                    const match = text.match(pattern.regex)
                    if (match) {
                      pattern.handler(match, startOfLine + 1)
                    }
                  }
                })
              }
            }
            
            return DecorationSet.create(newState.doc, decorations)
          }
        },
        props: {
          decorations(state) {
            return this.getState(state)
          },
          handleKeyDown(view, event) {
            if (event.key === 'Enter') {
              const { state, dispatch } = view
              const { selection } = state
              
              if (selection instanceof TextSelection) {
                const $pos = selection.$from
                const node = $pos.parent
                
                if (node && node.type.name === 'paragraph' && node.textContent) {
                  const text = node.textContent
                  
                  // Check for markdown patterns and convert them
                  let converted = false
                  const tr = state.tr
                  const startOfLine = $pos.start()
                  
                  // Headers
                  const headerMatch = text.match(/^(#{1,6})\s+(.*)$/)
                  if (headerMatch) {
                    const level = headerMatch[1].length
                    const content = headerMatch[2]
                    const heading = state.schema.nodes.heading.create({ level }, state.schema.text(content))
                    tr.replaceRangeWith(startOfLine - 1, startOfLine - 1 + node.nodeSize, heading)
                    converted = true
                  }
                  
                  // Bold
                  if (!converted) {
                    const boldRegex = /\*\*([^*]+)\*\*/g
                    let match
                    let offset = 0
                    
                    while ((match = boldRegex.exec(text)) !== null) {
                      const start = startOfLine + match.index! - offset
                      const end = start + match[0].length
                      const content = match[1]
                      
                      tr.removeMark(start, end, state.schema.marks.bold)
                      tr.delete(start, start + 2) // Remove opening **
                      tr.delete(start + content.length, start + content.length + 2) // Remove closing **
                      tr.addMark(start, start + content.length, state.schema.marks.bold.create())
                      
                      offset += 4 // Removed 4 characters
                      converted = true
                    }
                  }
                  
                  // Similar conversions for italic, strikethrough, code...
                  
                  if (converted) {
                    dispatch(tr)
                    return true
                  }
                }
              }
            }
            
            return false
          }
        }
      })
    ]
  }
})