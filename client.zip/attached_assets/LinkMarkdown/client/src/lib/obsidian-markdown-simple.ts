import { Extension } from '@tiptap/core'
import { Plugin, PluginKey } from '@tiptap/pm/state'
import { Decoration, DecorationSet } from '@tiptap/pm/view'
import { Node as ProseMirrorNode } from '@tiptap/pm/model'

export const ObsidianMarkdownSimple = Extension.create({
  name: 'obsidianMarkdownSimple',

  addProseMirrorPlugins() {
    return [
      new Plugin({
        key: new PluginKey('obsidianMarkdownSimple'),
        
        props: {
          handleKeyDown(view, event) {
            const { state } = view
            const { selection } = state
            
            // Handle Enter key - convert markdown to formatting
            if (event.key === 'Enter' && selection.empty) {
              const $pos = selection.$from
              const node = $pos.parent
              
              if (node.type.name === 'paragraph') {
                const text = node.textContent
                const nodeStart = $pos.start()
                const nodeEnd = $pos.end()
                
                // Check for heading syntax
                const headingMatch = text.match(/^(#{1,6})\s+(.*)$/)
                if (headingMatch) {
                  const level = headingMatch[1].length
                  const content = headingMatch[2]
                  
                  const tr = state.tr
                    .setBlockType(nodeStart, nodeEnd, state.schema.nodes.heading, { level })
                    .insertText(content, nodeStart, nodeEnd)
                  
                  view.dispatch(tr)
                  return true
                }
                
                // Check if text has any markdown syntax
                if (text.includes('**') || text.includes('*') || text.includes('~~') || text.includes('`')) {
                  let newContent = text
                  const marks: Array<{start: number, end: number, mark: any}> = []
                  
                  // Process all markdown patterns
                  const patterns = [
                    { pattern: /~~([^~]+)~~/g, markType: 'strike' },
                    { pattern: /\*\*([^*]+)\*\*/g, markType: 'strong' },
                    { pattern: /(?<!\*)\*([^*]+)\*(?!\*)/g, markType: 'em' },
                    { pattern: /`([^`]+)`/g, markType: 'code' }
                  ]
                  
                  // Collect all matches
                  for (const { pattern, markType } of patterns) {
                    let match
                    while ((match = pattern.exec(text)) !== null) {
                      marks.push({
                        start: match.index,
                        end: match.index + match[0].length,
                        mark: { type: markType, content: match[1] }
                      })
                    }
                  }
                  
                  // Sort marks by position
                  marks.sort((a, b) => a.start - b.start)
                  
                  // Apply marks to create formatted content
                  if (marks.length > 0) {
                    const tr = state.tr
                    tr.delete(nodeStart, nodeEnd)
                    
                    let currentPos = nodeStart
                    let lastIndex = 0
                    
                    for (const markInfo of marks) {
                      // Add text before mark
                      if (lastIndex < markInfo.start) {
                        const beforeText = text.substring(lastIndex, markInfo.start)
                        tr.insertText(beforeText, currentPos)
                        currentPos += beforeText.length
                      }
                      
                      // Add marked content
                      tr.insertText(markInfo.mark.content, currentPos)
                      const markEnd = currentPos + markInfo.mark.content.length
                      
                      if (markInfo.mark.type === 'strong') {
                        tr.addMark(currentPos, markEnd, state.schema.marks.strong.create())
                      } else if (markInfo.mark.type === 'em') {
                        tr.addMark(currentPos, markEnd, state.schema.marks.em.create())
                      } else if (markInfo.mark.type === 'strike') {
                        tr.addMark(currentPos, markEnd, state.schema.marks.strike.create())
                      } else if (markInfo.mark.type === 'code') {
                        tr.addMark(currentPos, markEnd, state.schema.marks.code.create())
                      }
                      
                      currentPos = markEnd
                      lastIndex = markInfo.end
                    }
                    
                    // Add remaining text
                    if (lastIndex < text.length) {
                      tr.insertText(text.substring(lastIndex), currentPos)
                    }
                    
                    view.dispatch(tr)
                    return true
                  }
                }
              }
            }
            
            return false
          },
          
          decorations(state) {
            const decorations: Decoration[] = []
            const { doc, selection } = state
            
            doc.descendants((node: ProseMirrorNode, pos: number) => {
              // Show markdown syntax for headings when cursor is in the heading
              if (node.type.name === 'heading') {
                const nodeStart = pos + 1
                const nodeEnd = pos + node.nodeSize - 1
                
                // Check if cursor is within this heading
                const cursorInHeading = selection.from >= nodeStart && selection.from <= nodeEnd
                
                if (cursorInHeading) {
                  const level = node.attrs.level
                  const markdownPrefix = '#'.repeat(level) + ' '
                  
                  // Add the markdown syntax as a widget at the start of the heading
                  decorations.push(
                    Decoration.widget(nodeStart, () => {
                      const span = document.createElement('span')
                      span.textContent = markdownPrefix
                      span.style.color = '#64748b'
                      span.style.fontWeight = 'normal'
                      span.style.userSelect = 'none'
                      span.style.pointerEvents = 'none'
                      return span
                    }, { 
                      side: -1,
                      ignoreSelection: true
                    })
                  )
                }
              }
              
              // Handle paragraph text with markdown syntax
              if (node.type.name === 'paragraph') {
                const nodeStart = pos + 1
                const nodeEnd = pos + node.nodeSize - 1
                
                // Check if cursor is within this paragraph
                const cursorInParagraph = selection.from >= nodeStart && selection.from <= nodeEnd
                
                if (cursorInParagraph && node.textContent) {
                  const text = node.textContent
                  
                  // Check for heading syntax in paragraph
                  const headingMatch = text.match(/^(#{1,6})\s/)
                  if (headingMatch) {
                    const prefixLength = headingMatch[0].length
                    decorations.push(
                      Decoration.inline(nodeStart, nodeStart + prefixLength, {
                        style: 'color: #64748b; font-weight: normal;'
                      })
                    )
                  }
                  
                  // Show markdown syntax for inline formatting
                  const patterns = [
                    { regex: /~~([^~]+)~~/g, name: 'strike' },
                    { regex: /\*\*([^*]+)\*\*/g, name: 'bold' },
                    { regex: /\*([^*]+)\*/g, name: 'italic' },
                    { regex: /`([^`]+)`/g, name: 'code' }
                  ]
                  
                  for (const pattern of patterns) {
                    let match
                    while ((match = pattern.regex.exec(text)) !== null) {
                      // Skip italic if it's part of bold
                      if (pattern.name === 'italic') {
                        const beforeChar = text[match.index - 1]
                        const afterChar = text[match.index + match[0].length]
                        if (beforeChar === '*' || afterChar === '*') {
                          continue
                        }
                      }
                      
                      const matchStart = nodeStart + match.index
                      const matchEnd = matchStart + match[0].length
                      const syntaxLength = pattern.name === 'strike' || pattern.name === 'bold' ? 2 : 1
                      
                      // Style the opening markers
                      decorations.push(
                        Decoration.inline(matchStart, matchStart + syntaxLength, {
                          style: 'color: #64748b; font-weight: normal;'
                        })
                      )
                      
                      // Style the closing markers
                      decorations.push(
                        Decoration.inline(matchEnd - syntaxLength, matchEnd, {
                          style: 'color: #64748b; font-weight: normal;'
                        })
                      )
                    }
                  }
                }
              }
              
              return false
            })
            
            return DecorationSet.create(doc, decorations)
          }
        }
      })
    ]
  }
})