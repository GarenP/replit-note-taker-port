import { Extension } from '@tiptap/core'
import { Plugin, PluginKey } from '@tiptap/pm/state'
import { Decoration, DecorationSet } from '@tiptap/pm/view'
import { InputRule } from '@tiptap/core'

export const ObsidianComplete = Extension.create({
  name: 'obsidianComplete',
  
  priority: 1000, // High priority to override other extensions

  addOptions() {
    return {
      disableDefaults: true,
    }
  },
  
  addStorage() {
    return {
      lastProcessedParagraph: null,
    }
  },

  onCreate() {
    // Completely disable input rules for inline formatting
    const extensionsToDisable = ['bold', 'italic', 'strike', 'code']
    
    this.editor.extensionManager.extensions.forEach(ext => {
      if (extensionsToDisable.includes(ext.name)) {
        // Override the addInputRules method to return empty array
        ext.addInputRules = () => []
        ext.addPasteRules = () => []
      }
    })
  },

  addInputRules() {
    // Return empty array to prevent any automatic conversions
    return []
  },

  addProseMirrorPlugins() {
    return [
      new Plugin({
        key: new PluginKey('obsidianComplete'),
        
        props: {
          handleTextInput(view, from, to, text) {
            // Allow normal text input, but block automatic markdown conversions
            return false
          },
          
          handleKeyDown(view, event) {
            // Don't process Enter - just let normal behavior happen
            return false
          },
          
          decorations(state) {
            const decorations: Decoration[] = []
            const { doc, selection } = state
            

            
            doc.descendants((node, pos) => {
              const nodeStart = pos + 1
              const nodeEnd = pos + node.nodeSize - 1
              const cursorInNode = selection.from >= nodeStart && selection.from <= nodeEnd
              
              // Show markdown syntax for headings
              if (node.type.name === 'heading' && cursorInNode) {
                const level = node.attrs.level
                const prefix = '#'.repeat(level) + ' '
                
                decorations.push(
                  Decoration.widget(nodeStart, () => {
                    const span = document.createElement('span')
                    span.textContent = prefix
                    span.style.color = '#64748b'
                    span.style.fontWeight = 'normal'
                    span.style.userSelect = 'none'
                    span.style.pointerEvents = 'none'
                    return span
                  }, {
                    side: -1,
                    ignoreSelection: true
                  })
                )
              }
              
              // Show markdown syntax in paragraphs ONLY when cursor is in the node
              if (node.type.name === 'paragraph' && node.textContent && cursorInNode) {
                const text = node.textContent
                
                // Check if text actually contains markdown syntax
                const hasMarkdownSyntax = /(?:\*\*[^*]+\*\*)|(?:(?<!\*)\*[^*]+\*(?!\*))|(?:~~[^~]+~~)|(?:`[^`]+`)/.test(text)
                
                // If no markdown syntax in the text, don't show decorations
                if (!hasMarkdownSyntax) {
                  return false
                }
                
                // Additional check: if the node has any marks, skip decorations
                let hasMarks = false
                node.forEach((inline) => {
                  if (inline.marks.length > 0) {
                    hasMarks = true
                  }
                })
                
                if (hasMarks) {
                  return false
                }
                
                // Show heading syntax
                const headingMatch = text.match(/^(#{1,6})\s/)
                if (headingMatch) {
                  decorations.push(
                    Decoration.inline(nodeStart, nodeStart + headingMatch[0].length, {
                      style: 'color: #64748b;'
                    })
                  )
                }
                
                // Show inline markdown syntax with live preview
                const patterns = [
                  { regex: /~~([^~]+)~~/g, length: 2, style: 'text-decoration: line-through;' },
                  { regex: /\*\*([^*]+)\*\*/g, length: 2, style: 'font-weight: bold;' },
                  { regex: /(?<!\*)\*([^*]+)\*(?!\*)/g, length: 1, style: 'font-style: italic;' },
                  { regex: /`([^`]+)`/g, length: 1, style: 'background-color: #374151; padding: 2px 4px; border-radius: 4px; font-family: monospace;' }
                ]
                
                for (const pattern of patterns) {
                  let match
                  const regex = new RegExp(pattern.regex.source, pattern.regex.flags)
                  while ((match = regex.exec(text)) !== null) {
                    const start = nodeStart + match.index
                    const end = start + match[0].length
                    const contentStart = start + pattern.length
                    const contentEnd = end - pattern.length
                    
                    // Highlight opening syntax in gray
                    decorations.push(
                      Decoration.inline(start, contentStart, {
                        style: 'color: #64748b;'
                      })
                    )
                    
                    // Apply formatting to content
                    decorations.push(
                      Decoration.inline(contentStart, contentEnd, {
                        style: pattern.style
                      })
                    )
                    
                    // Highlight closing syntax in gray
                    decorations.push(
                      Decoration.inline(contentEnd, end, {
                        style: 'color: #64748b;'
                      })
                    )
                  }
                }
              }
              
              return false
            })
            
            return DecorationSet.create(doc, decorations)
          }
        }
      })
    ]
  }
})