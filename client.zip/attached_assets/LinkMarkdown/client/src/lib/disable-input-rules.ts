import { Extension } from '@tiptap/core'
import { Plugin } from '@tiptap/pm/state'

export const DisableInputRules = Extension.create({
  name: 'disableInputRules',

  addProseMirrorPlugins() {
    return [
      new Plugin({
        props: {
          handleTextInput(view, from, to, text) {
            // Prevent automatic list creation
            const { state } = view
            const $from = state.doc.resolve(from)
            const textBefore = $from.parent.textContent.slice(0, $from.parentOffset)
            
            // Check if we're at the start of a line
            if (textBefore === '') {
              // Prevent conversion of "1. ", "2. ", etc. to ordered lists
              if (/^\d+\.$/.test(text)) {
                return false // Let the text be inserted normally
              }
              // Prevent conversion of "- ", "* ", "+ " to bullet lists
              if (/^[-*+]$/.test(text)) {
                return false // Let the text be inserted normally
              }
            }
            
            return false // Let default behavior handle it
          }
        }
      })
    ]
  }
})