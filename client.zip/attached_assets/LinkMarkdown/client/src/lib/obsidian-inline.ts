import { Extension } from '@tiptap/core'
import { Plugin, PluginKey } from '@tiptap/pm/state'
import { Decoration, DecorationSet } from '@tiptap/pm/view'

export const ObsidianInline = Extension.create({
  name: 'obsidianInline',

  addOptions() {
    return {
      disableInputRules: true,
    }
  },

  onCreate() {
    // Disable all input rules for markdown syntax
    this.editor.extensionManager.extensions.forEach(extension => {
      if (extension.name === 'bold' || 
          extension.name === 'italic' || 
          extension.name === 'strike' || 
          extension.name === 'code') {
        if (extension.options.inputRules) {
          extension.options.inputRules = []
        }
      }
    })
  },

  addProseMirrorPlugins() {
    return [
      new Plugin({
        key: new PluginKey('obsidianInline'),
        
        props: {
          handleKeyDown(view, event) {
            const { state } = view
            const { selection } = state
            
            // Only process on Enter key
            if (event.key === 'Enter' && selection.empty) {
              const $pos = selection.$from
              const node = $pos.parent
              
              if (node.type.name === 'paragraph') {
                const text = node.textContent
                const nodeStart = $pos.start()
                const nodeEnd = $pos.end()
                
                // Process inline formatting
                let hasFormatting = false
                const replacements = []
                
                // Find all strikethrough
                let regex = /~~([^~]+)~~/g
                let match
                while ((match = regex.exec(text)) !== null) {
                  replacements.push({
                    start: match.index,
                    end: match.index + match[0].length,
                    content: match[1],
                    type: 'strike'
                  })
                  hasFormatting = true
                }
                
                // Find all bold
                regex = /\*\*([^*]+)\*\*/g
                while ((match = regex.exec(text)) !== null) {
                  replacements.push({
                    start: match.index,
                    end: match.index + match[0].length,
                    content: match[1],
                    type: 'bold'
                  })
                  hasFormatting = true
                }
                
                // Find all italic (not part of bold)
                regex = /(?<!\*)\*([^*]+)\*(?!\*)/g
                while ((match = regex.exec(text)) !== null) {
                  replacements.push({
                    start: match.index,
                    end: match.index + match[0].length,
                    content: match[1],
                    type: 'italic'
                  })
                  hasFormatting = true
                }
                
                // Find all code
                regex = /`([^`]+)`/g
                while ((match = regex.exec(text)) !== null) {
                  replacements.push({
                    start: match.index,
                    end: match.index + match[0].length,
                    content: match[1],
                    type: 'code'
                  })
                  hasFormatting = true
                }
                
                if (hasFormatting && replacements.length > 0) {
                  // Sort by position
                  replacements.sort((a, b) => a.start - b.start)
                  
                  // Build new content
                  const tr = state.tr
                  tr.delete(nodeStart, nodeEnd)
                  
                  let currentPos = nodeStart
                  let lastEnd = 0
                  
                  for (const replacement of replacements) {
                    // Insert text before this replacement
                    if (lastEnd < replacement.start) {
                      const beforeText = text.substring(lastEnd, replacement.start)
                      tr.insertText(beforeText, currentPos)
                      currentPos += beforeText.length
                    }
                    
                    // Insert the formatted content
                    tr.insertText(replacement.content, currentPos)
                    const markEnd = currentPos + replacement.content.length
                    
                    // Apply the mark
                    if (replacement.type === 'strike' && state.schema.marks.strike) {
                      tr.addMark(currentPos, markEnd, state.schema.marks.strike.create())
                    } else if (replacement.type === 'bold' && state.schema.marks.strong) {
                      tr.addMark(currentPos, markEnd, state.schema.marks.strong.create())
                    } else if (replacement.type === 'italic' && state.schema.marks.em) {
                      tr.addMark(currentPos, markEnd, state.schema.marks.em.create())
                    } else if (replacement.type === 'code' && state.schema.marks.code) {
                      tr.addMark(currentPos, markEnd, state.schema.marks.code.create())
                    }
                    
                    currentPos = markEnd
                    lastEnd = replacement.end
                  }
                  
                  // Insert remaining text
                  if (lastEnd < text.length) {
                    tr.insertText(text.substring(lastEnd), currentPos)
                  }
                  
                  view.dispatch(tr)
                  return true
                }
              }
            }
            
            return false
          },
          
          handleTextInput(view, from, to, text) {
            // Prevent automatic markdown conversion on text input
            const { state } = view
            const { schema } = state
            
            // Check if the input would trigger markdown formatting
            const beforeText = state.doc.textBetween(Math.max(0, from - 10), from)
            const afterText = state.doc.textBetween(to, Math.min(state.doc.content.size, to + 10))
            const fullText = beforeText + text + afterText
            
            // Block automatic conversions
            if (fullText.includes('**') || 
                fullText.includes('*') || 
                fullText.includes('~~') || 
                fullText.includes('`')) {
              // Just insert the text without any conversion
              const tr = state.tr.insertText(text, from, to)
              view.dispatch(tr)
              return true
            }
            
            return false
          },
          
          decorations(state) {
            const decorations: Decoration[] = []
            const { doc, selection } = state
            
            doc.descendants((node, pos) => {
              // For paragraphs, show markdown syntax when cursor is in the paragraph
              if (node.type.name === 'paragraph' && node.textContent) {
                const nodeStart = pos + 1
                const nodeEnd = pos + node.nodeSize - 1
                
                if (selection.from >= nodeStart && selection.from <= nodeEnd) {
                  const text = node.textContent
                  
                  // Show inline markdown syntax
                  const patterns = [
                    { regex: /~~([^~]+)~~/g, length: 2 },
                    { regex: /\*\*([^*]+)\*\*/g, length: 2 },
                    { regex: /(?<!\*)\*([^*]+)\*(?!\*)/g, length: 1 },
                    { regex: /`([^`]+)`/g, length: 1 }
                  ]
                  
                  for (const pattern of patterns) {
                    let match
                    const regex = new RegExp(pattern.regex.source, pattern.regex.flags)
                    while ((match = regex.exec(text)) !== null) {
                      const start = nodeStart + match.index
                      const end = start + match[0].length
                      
                      // Highlight opening syntax
                      decorations.push(
                        Decoration.inline(start, start + pattern.length, {
                          style: 'color: #64748b;'
                        })
                      )
                      
                      // Highlight closing syntax
                      decorations.push(
                        Decoration.inline(end - pattern.length, end, {
                          style: 'color: #64748b;'
                        })
                      )
                    }
                  }
                }
              }
              
              return false
            })
            
            return DecorationSet.create(doc, decorations)
          }
        }
      })
    ]
  }
})