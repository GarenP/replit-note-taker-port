import { Extension } from '@tiptap/core'
import { Plugin, PluginKey } from '@tiptap/pm/state'
import { Decoration, DecorationSet } from '@tiptap/pm/view'

export const MarkdownPreview = Extension.create({
  name: 'markdownPreview',

  addOptions() {
    return {
      types: ['paragraph', 'heading']
    }
  },

  addProseMirrorPlugins() {
    const pluginKey = new PluginKey('markdownPreview')
    
    return [
      new Plugin({
        key: pluginKey,
        state: {
          init(_, { doc }) {
            return DecorationSet.empty
          },
          apply(tr, decorationSet, oldState, newState) {
            // Only update decorations when necessary
            if (tr.docChanged || tr.selectionSet) {
              const decorations: Decoration[] = []
              
              newState.doc.descendants((node, pos) => {
                if (node.type.name !== 'paragraph' || !node.textContent) return
                
                const text = node.textContent
                console.log('MarkdownPreview checking node:', { text, pos })
                const patterns = [
                  {
                    name: 'bold',
                    regex: /\*\*([^*]+)\*\*/g,
                    style: 'font-weight: bold;'
                  },
                  {
                    name: 'italic', 
                    regex: /(?<!\*)\*([^*]+)\*(?!\*)/g,
                    style: 'font-style: italic;'
                  },
                  {
                    name: 'strike',
                    regex: /~~([^~]+)~~/g,
                    style: 'text-decoration: line-through;'
                  },
                  {
                    name: 'code',
                    regex: /`([^`]+)`/g,
                    style: 'background-color: #374151; padding: 2px 4px; border-radius: 4px; font-family: monospace; font-size: 0.9em;'
                  }
                ]
                
                patterns.forEach(pattern => {
                  const regex = new RegExp(pattern.regex.source, 'g')
                  let match
                  
                  while ((match = regex.exec(text)) !== null) {
                    const syntaxLength = pattern.name === 'italic' || pattern.name === 'code' ? 1 : 2
                    const start = pos + 1 + match.index
                    const end = start + match[0].length
                    const contentStart = start + syntaxLength
                    const contentEnd = end - syntaxLength
                    
                    console.log(`Found ${pattern.name} match:`, { 
                      match: match[0], 
                      start, 
                      end,
                      contentStart,
                      contentEnd 
                    })
                    
                    // Style opening syntax
                    decorations.push(
                      Decoration.inline(start, contentStart, {
                        style: 'color: #64748b;',
                        class: 'markdown-syntax'
                      })
                    )
                    
                    // Style content
                    decorations.push(
                      Decoration.inline(contentStart, contentEnd, {
                        style: pattern.style,
                        class: `markdown-preview-${pattern.name}`
                      })
                    )
                    
                    // Style closing syntax
                    decorations.push(
                      Decoration.inline(contentEnd, end, {
                        style: 'color: #64748b;',
                        class: 'markdown-syntax'
                      })
                    )
                  }
                })
              })
              
              return DecorationSet.create(newState.doc, decorations)
            }
            
            return decorationSet.map(tr.mapping, tr.doc)
          }
        },
        props: {
          decorations(state) {
            return pluginKey.getState(state)
          }
        }
      })
    ]
  }
})