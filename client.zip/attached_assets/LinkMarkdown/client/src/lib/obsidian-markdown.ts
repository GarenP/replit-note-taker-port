import { Extension } from '@tiptap/core'
import { Plugin, PluginKey } from '@tiptap/pm/state'
import { Decoration, DecorationSet } from '@tiptap/pm/view'
import { Node as ProseMirrorNode } from '@tiptap/pm/model'
import { InputRule } from '@tiptap/core'

export interface ObsidianMarkdownOptions {
  types: string[]
}

export const ObsidianMarkdown = Extension.create<ObsidianMarkdownOptions>({
  name: 'obsidianMarkdown',

  addOptions() {
    return {
      types: ['heading', 'paragraph'],
    }
  },

  addInputRules() {
    return [
      // Disable all default input rules by returning empty array
    ]
  },

  addProseMirrorPlugins() {
    return [
      new Plugin({
        key: new PluginKey('obsidianMarkdown'),
        
        props: {
          handleKeyDown(view, event) {
            const { state } = view
            const { selection } = state
            
            // Handle Enter key - convert markdown to formatting
            if (event.key === 'Enter' && selection.empty) {
              const $pos = selection.$from
              const node = $pos.parent
              
              if (node.type.name === 'paragraph') {
                const text = node.textContent
                
                // Check for heading syntax
                const headingMatch = text.match(/^(#{1,6})\s+(.*)$/)
                if (headingMatch) {
                  const level = headingMatch[1].length
                  const content = headingMatch[2]
                  
                  const nodeStart = $pos.start()
                  const nodeEnd = $pos.end()
                  
                  const tr = state.tr
                    .setBlockType(nodeStart, nodeEnd, state.schema.nodes.heading, { level })
                    .insertText(content, nodeStart, nodeEnd)
                  
                  view.dispatch(tr)
                  return true
                }
                
                // Process inline formatting
                const nodeStart = $pos.start()
                const nodeEnd = $pos.end()
                let processedText = text
                let hasFormatting = false
                
                // Create a new paragraph with formatted content
                const tr = state.tr
                tr.delete(nodeStart, nodeEnd)
                
                let currentPos = nodeStart
                
                // Process text with inline formatting
                while (processedText.length > 0) {
                  let found = false
                  
                  // Check for strikethrough ~~text~~
                  const strikeMatch = processedText.match(/^(.*?)~~([^~]+)~~(.*)$/)
                  if (strikeMatch) {
                    const [, before, content, after] = strikeMatch
                    
                    // Insert text before
                    if (before) {
                      tr.insertText(before, currentPos)
                      currentPos += before.length
                    }
                    
                    // Insert strikethrough content
                    tr.insertText(content, currentPos)
                    tr.addMark(currentPos, currentPos + content.length, state.schema.marks.strike.create())
                    currentPos += content.length
                    
                    processedText = after
                    hasFormatting = true
                    found = true
                  }
                  
                  // Check for bold **text**
                  if (!found) {
                    const boldMatch = processedText.match(/^(.*?)\*\*([^*]+)\*\*(.*)$/)
                    if (boldMatch) {
                      const [, before, content, after] = boldMatch
                      
                      // Insert text before
                      if (before) {
                        tr.insertText(before, currentPos)
                        currentPos += before.length
                      }
                      
                      // Insert bold content
                      tr.insertText(content, currentPos)
                      tr.addMark(currentPos, currentPos + content.length, state.schema.marks.strong.create())
                      currentPos += content.length
                      
                      processedText = after
                      hasFormatting = true
                      found = true
                    }
                  }
                  
                  // Check for italic *text*
                  if (!found) {
                    const italicMatch = processedText.match(/^(.*?)\*([^*]+)\*(.*)$/)
                    if (italicMatch) {
                      const [, before, content, after] = italicMatch
                      
                      // Check if this is not part of ** (bold)
                      const beforeStar = before.slice(-1)
                      const afterStar = after.slice(0, 1)
                      
                      if (beforeStar !== '*' && afterStar !== '*') {
                        // Insert text before
                        if (before) {
                          tr.insertText(before, currentPos)
                          currentPos += before.length
                        }
                        
                        // Insert italic content
                        tr.insertText(content, currentPos)
                        tr.addMark(currentPos, currentPos + content.length, state.schema.marks.em.create())
                        currentPos += content.length
                        
                        processedText = after
                        hasFormatting = true
                        found = true
                      }
                    }
                  }
                  
                  // Check for code `text`
                  if (!found) {
                    const codeMatch = processedText.match(/^(.*?)`([^`]+)`(.*)$/)
                    if (codeMatch) {
                      const [, before, content, after] = codeMatch
                      
                      // Insert text before
                      if (before) {
                        tr.insertText(before, currentPos)
                        currentPos += before.length
                      }
                      
                      // Insert code content
                      tr.insertText(content, currentPos)
                      tr.addMark(currentPos, currentPos + content.length, state.schema.marks.code.create())
                      currentPos += content.length
                      
                      processedText = after
                      hasFormatting = true
                      found = true
                    }
                  }
                  
                  if (!found) {
                    // No more formatting found, insert remaining text
                    tr.insertText(processedText, currentPos)
                    break
                  }
                }
                
                if (hasFormatting) {
                  view.dispatch(tr)
                  return true
                }
              }
            }
            
            return false
          },
          
          decorations(state) {
            const decorations: Decoration[] = []
            const { doc, selection } = state
            
            doc.descendants((node: ProseMirrorNode, pos: number) => {
              // Show markdown syntax for headings when cursor is in the heading
              if (node.type.name === 'heading') {
                const nodeStart = pos + 1
                const nodeEnd = pos + node.nodeSize - 1
                
                // Check if cursor is within this heading
                const cursorInHeading = selection.from >= nodeStart && selection.from <= nodeEnd
                
                if (cursorInHeading) {
                  const level = node.attrs.level
                  const markdownPrefix = '#'.repeat(level) + ' '
                  
                  // Add the markdown syntax as a widget at the start of the heading
                  decorations.push(
                    Decoration.widget(nodeStart, () => {
                      const span = document.createElement('span')
                      span.textContent = markdownPrefix
                      span.style.color = '#64748b'
                      span.style.fontWeight = 'normal'
                      span.style.userSelect = 'none'
                      span.style.pointerEvents = 'none'
                      span.style.marginRight = '0'
                      return span
                    }, { 
                      side: -1,
                      ignoreSelection: true
                    })
                  )
                }
              }
              
              // Handle paragraph text with markdown syntax
              if (node.type.name === 'paragraph') {
                const nodeStart = pos + 1
                const nodeEnd = pos + node.nodeSize - 1
                
                // Check if cursor is within this paragraph
                const cursorInParagraph = selection.from >= nodeStart && selection.from <= nodeEnd
                
                if (cursorInParagraph && node.textContent) {
                  const text = node.textContent
                  
                  // Check for heading syntax in paragraph
                  const headingMatch = text.match(/^(#{1,6})\s/)
                  if (headingMatch) {
                    const prefixLength = headingMatch[0].length
                    decorations.push(
                      Decoration.inline(nodeStart, nodeStart + prefixLength, {
                        style: 'color: #64748b; font-weight: normal;'
                      })
                    )
                  }
                  
                  // Show markdown syntax for inline formatting
                  // Strikethrough ~~text~~
                  let strikeMatch
                  const strikeRegex = /~~([^~]+)~~/g
                  while ((strikeMatch = strikeRegex.exec(text)) !== null) {
                    const matchStart = nodeStart + strikeMatch.index
                    const matchEnd = matchStart + strikeMatch[0].length
                    
                    // Style the ~~ markers
                    decorations.push(
                      Decoration.inline(matchStart, matchStart + 2, {
                        style: 'color: #64748b; font-weight: normal;'
                      })
                    )
                    decorations.push(
                      Decoration.inline(matchEnd - 2, matchEnd, {
                        style: 'color: #64748b; font-weight: normal;'
                      })
                    )
                  }
                  
                  // Bold **text**
                  let boldMatch
                  const boldRegex = /\*\*([^*]+)\*\*/g
                  while ((boldMatch = boldRegex.exec(text)) !== null) {
                    const matchStart = nodeStart + boldMatch.index
                    const matchEnd = matchStart + boldMatch[0].length
                    
                    // Style the ** markers
                    decorations.push(
                      Decoration.inline(matchStart, matchStart + 2, {
                        style: 'color: #64748b; font-weight: normal;'
                      })
                    )
                    decorations.push(
                      Decoration.inline(matchEnd - 2, matchEnd, {
                        style: 'color: #64748b; font-weight: normal;'
                      })
                    )
                  }
                  
                  // Italic *text* (but not if it's part of **)
                  let italicMatch
                  const italicRegex = /\*([^*]+)\*/g
                  while ((italicMatch = italicRegex.exec(text)) !== null) {
                    // Check if this is not part of ** (bold)
                    const beforeChar = text[italicMatch.index - 1]
                    const afterChar = text[italicMatch.index + italicMatch[0].length]
                    
                    if (beforeChar !== '*' && afterChar !== '*') {
                      const matchStart = nodeStart + italicMatch.index
                      const matchEnd = matchStart + italicMatch[0].length
                      
                      // Style the * markers
                      decorations.push(
                        Decoration.inline(matchStart, matchStart + 1, {
                          style: 'color: #64748b; font-weight: normal;'
                        })
                      )
                      decorations.push(
                        Decoration.inline(matchEnd - 1, matchEnd, {
                          style: 'color: #64748b; font-weight: normal;'
                        })
                      )
                    }
                  }
                  
                  // Code `text`
                  let codeMatch
                  const codeRegex = /`([^`]+)`/g
                  while ((codeMatch = codeRegex.exec(text)) !== null) {
                    const matchStart = nodeStart + codeMatch.index
                    const matchEnd = matchStart + codeMatch[0].length
                    
                    // Style the ` markers
                    decorations.push(
                      Decoration.inline(matchStart, matchStart + 1, {
                        style: 'color: #64748b; font-weight: normal;'
                      })
                    )
                    decorations.push(
                      Decoration.inline(matchEnd - 1, matchEnd, {
                        style: 'color: #64748b; font-weight: normal;'
                      })
                    )
                  }
                  

                }
              }
              
              return false
            })
            
            return DecorationSet.create(doc, decorations)
          }
        }
      })
    ]
  }
})