import { Extension } from '@tiptap/core'
import { Plugin, PluginKey } from '@tiptap/pm/state'
import { Decoration, DecorationSet } from '@tiptap/pm/view'

export const ObsidianHeaders = Extension.create({
  name: 'obsidianHeaders',

  addProseMirrorPlugins() {
    return [
      new Plugin({
        key: new PluginKey('obsidianHeaders'),
        
        props: {
          handleKeyDown(view, event) {
            const { state } = view
            const { selection } = state
            
            // Only process on Enter key
            if (event.key === 'Enter' && selection.empty) {
              const $pos = selection.$from
              const node = $pos.parent
              
              if (node.type.name === 'paragraph') {
                const text = node.textContent
                const nodeStart = $pos.start()
                const nodeEnd = $pos.end()
                
                // Check for heading syntax
                const headingMatch = text.match(/^(#{1,6})\s+(.*)$/)
                if (headingMatch) {
                  const level = headingMatch[1].length
                  const content = headingMatch[2]
                  
                  const tr = state.tr
                    .setBlockType(nodeStart, nodeEnd, state.schema.nodes.heading, { level })
                    .insertText(content, nodeStart, nodeEnd)
                  
                  view.dispatch(tr)
                  return true
                }
              }
            }
            
            return false
          },
          
          decorations(state) {
            const decorations: Decoration[] = []
            const { doc, selection } = state
            
            doc.descendants((node, pos) => {
              // For headings, show the markdown syntax when cursor is in the heading
              if (node.type.name === 'heading') {
                const nodeStart = pos + 1
                const nodeEnd = pos + node.nodeSize - 1
                
                if (selection.from >= nodeStart && selection.from <= nodeEnd) {
                  const level = node.attrs.level
                  const prefix = '#'.repeat(level) + ' '
                  
                  decorations.push(
                    Decoration.widget(nodeStart, () => {
                      const span = document.createElement('span')
                      span.textContent = prefix
                      span.style.color = '#64748b'
                      span.style.fontWeight = 'normal'
                      span.style.userSelect = 'none'
                      span.style.pointerEvents = 'none'
                      return span
                    }, {
                      side: -1,
                      ignoreSelection: true
                    })
                  )
                }
              }
              
              // For paragraphs, show heading syntax when cursor is in the paragraph
              if (node.type.name === 'paragraph' && node.textContent) {
                const nodeStart = pos + 1
                const nodeEnd = pos + node.nodeSize - 1
                
                if (selection.from >= nodeStart && selection.from <= nodeEnd) {
                  const text = node.textContent
                  
                  // Show heading syntax
                  const headingMatch = text.match(/^(#{1,6})\s/)
                  if (headingMatch) {
                    decorations.push(
                      Decoration.inline(nodeStart, nodeStart + headingMatch[0].length, {
                        style: 'color: #64748b;'
                      })
                    )
                  }
                }
              }
              
              return false
            })
            
            return DecorationSet.create(doc, decorations)
          }
        }
      })
    ]
  }
})