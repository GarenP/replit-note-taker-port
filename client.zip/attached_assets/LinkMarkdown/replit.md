# replit.md

## Overview

This is a minimalist full-stack note-taking application built with React, Node.js, and Express. The application features a single, distraction-free editor interface focused on seamless writing and editing experience with a dark aesthetic and clean design.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture
- **Framework**: React 18 with TypeScript
- **Build Tool**: Vite for fast development and optimized builds
- **Styling**: Tailwind CSS with shadcn/ui components
- **State Management**: TanStack Query for server state management
- **Routing**: Wouter for lightweight client-side routing
- **Editor**: TipTap for rich text editing with markdown support

### Backend Architecture
- **Framework**: Express.js with TypeScript
- **Runtime**: Node.js with ES modules
- **API Design**: RESTful API with JSON responses
- **Development**: Hot module replacement via Vite middleware in development

### Database Layer
- **ORM**: Drizzle ORM for type-safe database operations
- **Database**: PostgreSQL (configured via Drizzle config)
- **Connection**: Neon Database serverless driver for PostgreSQL
- **Schema**: Strongly typed schemas with Zod validation

## Key Components

### Editor Interface
The application features a single, minimal editor interface focused on distraction-free writing:
- **Minimal Editor**: Clean, centered writing interface with dark theme
- **Auto-save**: Automatic saving with debounced updates
- **Responsive Design**: Optimized for both desktop and mobile

### Rich Text Editing
- **TipTap**: Primary rich text editor with Obsidian-style markdown support
- **Features**: Headings, paragraphs, lists, blockquotes, code blocks, and inline formatting
- **Obsidian-style Behavior**: Markdown syntax stays visible while editing (gray colored), only converts to formatting when pressing Enter
- **Dark Theme**: Carefully designed prose styling for comfortable reading and writing

### Recent Changes (January 15, 2025)
- Fixed Obsidian-style markdown editing where syntax (**, *, ~~, `) stays visible during editing
- Formatting only applies when pressing Enter, matching Obsidian behavior
- Gray color (#64748b) for markdown syntax indicators
- Replaced Obsidian-style markdown preview with formatting toolbar
- Added TipTap toolbar with buttons for bold, italic, strikethrough, code, headings, lists, quotes, undo/redo
- Simplified editor implementation for better reliability
- Added ObsidianMarkdownV2 extension for syntax visibility on current line
- Added buttons for code block, blockquote, and horizontal rule
- Created DisableInputRules extension to prevent automatic list conversion
- Fixed issue where numbers followed by periods were auto-converting to lists

### UI Components
- **Design System**: shadcn/ui components with Radix UI primitives
- **Theme**: Dark theme with neutral color palette
- **Responsive**: Mobile-first design with responsive layouts

## Data Flow

### Client-Server Communication
1. Client makes HTTP requests to `/api/*` endpoints
2. Server handles CRUD operations for notes
3. TanStack Query manages caching and synchronization
4. Optimistic updates for smooth user experience

### State Management
- **Server State**: TanStack Query for notes data
- **Local State**: React hooks for component state
- **Form State**: React Hook Form for form handling

### Authentication
- **Current Implementation**: Demo user (ID: 1) hardcoded
- **Session Management**: Basic session structure prepared
- **Storage**: In-memory storage for development

## External Dependencies

### Core Dependencies
- **React Ecosystem**: React 18, React DOM, React Hook Form
- **UI Framework**: Radix UI components, Tailwind CSS
- **Database**: Drizzle ORM, Neon Database serverless
- **Editor**: TipTap with StarterKit for rich text editing
- **Validation**: Zod for schema validation
- **Utilities**: clsx, class-variance-authority, date-fns

### Development Dependencies
- **Build Tools**: Vite, esbuild, TypeScript
- **Development**: tsx for TypeScript execution
- **Linting**: ESLint and Prettier (configured via Vite)

## Deployment Strategy

### Build Process
1. **Frontend**: Vite builds optimized React bundle to `dist/public`
2. **Backend**: esbuild bundles server code to `dist/index.js`
3. **Database**: Drizzle migrations stored in `./migrations`

### Environment Configuration
- **Database**: Requires `DATABASE_URL` environment variable
- **Development**: Uses Vite dev server with HMR
- **Production**: Serves static files from Express server

### Scripts
- `npm run dev`: Start development server with hot reloading
- `npm run build`: Build for production
- `npm run start`: Start production server
- `npm run db:push`: Push database schema changes

### Replit Integration
- **Development**: Replit-specific plugins for error overlay and cartographer
- **Banner**: Replit development banner for external access
- **File System**: Configured for Replit's file system structure

The application is designed to be easily deployed on Replit with minimal configuration, using environment variables for database connection and supporting both development and production modes.